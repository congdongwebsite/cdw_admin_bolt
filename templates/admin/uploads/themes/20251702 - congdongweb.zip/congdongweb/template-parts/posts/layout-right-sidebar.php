<?php
/**
 * Posts layout right sidebar.
 *
 * @package          Congdongweb\Templates
 * @congdongweb-version 3.16.0
 */

do_action('congdongweb_before_blog');
?>

<?php if(!is_single() && congdongweb_option('blog_featured') == 'top'){ get_template_part('template-parts/posts/featured-posts'); } ?>

<div class="row row-large <?php if(congdongweb_option('blog_layout_divider')) echo 'row-divided ';?>">

	<div class="large-9 col">
	<?php if(!is_single() && congdongweb_option('blog_featured') == 'content'){ get_template_part('template-parts/posts/featured-posts'); } ?>
	<?php
		if(is_single()){
			get_template_part( 'template-parts/posts/single');
			comments_template();
		} elseif(congdongweb_option('blog_style_archive') && (is_archive() || is_search())){
			get_template_part( 'template-parts/posts/archive', congdongweb_option('blog_style_archive') );
		} else {
			get_template_part( 'template-parts/posts/archive', congdongweb_option('blog_style') );
		}
	?>
	</div>
	<div class="post-sidebar large-3 col">
		<?php congdongweb_sticky_column_open( 'blog_sticky_sidebar' ); ?>
		<?php get_sidebar(); ?>
		<?php congdongweb_sticky_column_close( 'blog_sticky_sidebar' ); ?>
	</div>
</div>

<?php
	do_action('congdongweb_after_blog');
?>
