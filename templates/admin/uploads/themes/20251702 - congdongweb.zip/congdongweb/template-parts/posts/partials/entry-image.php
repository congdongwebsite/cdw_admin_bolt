<?php
/**
 * Post-entry image.
 *
 * @package          Congdongweb\Templates
 * @congdongweb-version 3.16.0
 */

?>
<a href="<?php the_permalink();?>">
    <?php the_post_thumbnail('large'); ?>
</a>
