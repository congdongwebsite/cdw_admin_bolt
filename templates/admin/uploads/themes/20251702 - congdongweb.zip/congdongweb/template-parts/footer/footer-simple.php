<?php
/**
 * Simple footer.
 *
 * @package          Congdongweb\Templates
 * @congdongweb-version 3.16.0
 */

get_template_part( 'template-parts/footer/footer-absolute' );
