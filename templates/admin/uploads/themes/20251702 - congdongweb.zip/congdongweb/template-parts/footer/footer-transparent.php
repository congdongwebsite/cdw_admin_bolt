<?php
/**
 * Transparent footer.
 *
 * @package          Congdongweb\Templates
 * @congdongweb-version 3.16.0
 */

?>
<div class="absolute-footer fixed dark nav-dark text-center">
		<div class="footer-primary">
				<div class="copyright-footer">
					<?php if(congdongweb_option('footer_left_text')) { echo do_shortcode(congdongweb_option('footer_left_text'));} ?>
				</div>
		</div>
</div>
