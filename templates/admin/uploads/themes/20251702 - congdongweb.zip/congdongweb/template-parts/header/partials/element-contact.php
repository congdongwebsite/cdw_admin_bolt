<?php
/**
 * Contact element.
 *
 * @package          Congdongweb\Templates
 * @congdongweb-version 3.16.0
 */

?>
<li class="header-contact-wrapper">
	<?php
		$class = '';
		$icon_size = congdongweb_option('contact_icon_size');
		$class_link = 'tooltip';
		$nav = 'nav-divided nav-uppercase';
		$label = true;

		if(congdongweb_option('contact_style') == 'icons'){
			$label = false;
		}
	?>
	<ul id="header-contact" class="nav <?php echo $nav; ?> header-contact">
		<?php if(congdongweb_option('contact_location')){ ?>
			<li class="<?php echo $class; ?>">
			  <a target="_blank" rel="noopener noreferrer" href="https://maps.google.com/?q=<?php echo congdongweb_option('contact_location'); ?>" title="<?php echo congdongweb_option('contact_location'); ?>" class="<?php echo $class_link;?>">
			  	 <?php echo get_congdongweb_icon('icon-map-pin-fill',$icon_size); ?>
			     <span>
			     	<?php
			     	$location_label = congdongweb_option('contact_location_label');
		       		if($location_label && $label){
		       			echo $location_label;
		       		} else if($label){
		       			_e('Location','congdongweb');
			    	} ?>
			     </span>
			  </a>
			</li>
			<?php } ?>

			<?php
			 $contact_email = get_theme_mod('contact_email','youremail@gmail.com');
			 if($contact_email){ ?>
			<li class="<?php echo $class; ?>">
			  <a href="mailto:<?php echo $contact_email; ?>" class="<?php echo $class_link;?>" title="<?php echo  $contact_email; ?>">
				  <?php echo get_congdongweb_icon('icon-envelop',$icon_size); ?>
			       <span>
			       	<?php
			       	$contact_label = get_theme_mod('contact_email_label');
		       		if($contact_label && $label) {
		       			echo $contact_label;
		       		} else if($label){
		       			_e('Contact','congdongweb');
			    	} ?>
			       </span>
			  </a>
			</li>
			<?php } ?>

			<?php
			$contact_hours = get_theme_mod('contact_hours','08:00 - 17:00');
			if($contact_hours){
				$contact_hours_details = get_theme_mod('contact_hours_details');
			?>
			<li class="<?php echo $class; ?>">
			  <a class="<?php echo $class_link;?>" title="<?php echo $contact_hours; ?><?php if($contact_hours_details) echo ' | '.$contact_hours_details; ?> ">
			  	   <?php echo get_congdongweb_icon('icon-clock',$icon_size); ?>
			        <span><?php if($label) echo $contact_hours; ?></span>
			  </a>
			 </li>
			<?php } ?>

			<?php if(congdongweb_option('contact_phone')){ ?>
			<li class="<?php echo $class; ?>">
			  <a href="tel:<?php echo congdongweb_option('contact_phone'); ?>" class="<?php echo $class_link;?>" title="<?php echo congdongweb_option('contact_phone'); ?>">
			     <?php echo get_congdongweb_icon('icon-phone',$icon_size); ?>
			      <span><?php if($label) echo congdongweb_option('contact_phone'); ?></span>
			  </a>
			</li>
			<?php } ?>
	</ul>
</li>
