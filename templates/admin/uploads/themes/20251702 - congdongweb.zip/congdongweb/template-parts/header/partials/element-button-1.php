<?php
/**
 * Button 1 element.
 *
 * @package          Congdongweb\Templates
 * @congdongweb-version 3.16.0
 */

?>
<li class="html header-button-1">
	<div class="header-button">
	<?php
		echo do_shortcode('[button text="'.congdongweb_option('header_button_1').'" link="'.congdongweb_option('header_button_1_link').'" target="'.congdongweb_option('header_button_1_link_target').'" rel="'.get_theme_mod('header_button_1_link_rel').'" radius="'.congdongweb_option('header_button_1_radius').'" size="'.congdongweb_option('header_button_1_size').'" color="'.congdongweb_option('header_button_1_color').'" depth="'.congdongweb_option('header_button_1_depth').'"  depth_hover="'.congdongweb_option('header_button_1_depth_hover').'" style="'.congdongweb_option('header_button_1_style').'"]');
	?>
	</div>
</li>


