<?php
/**
 * Menu icon element.
 *
 * @package          Congdongweb\Templates
 * @congdongweb-version 3.16.0
 */

$icon_style = congdongweb_option('menu_icon_style');
?>
<li class="nav-icon has-icon">
  <?php if($icon_style) { ?><div class="header-button"><?php } ?>
		<a href="#" data-open="#main-menu" data-pos="<?php echo congdongweb_option('mobile_overlay');?>" data-bg="main-menu-overlay" data-color="<?php echo congdongweb_option('mobile_overlay_color');?>" class="<?php echo get_congdongweb_icon_class($icon_style, 'small'); ?>" aria-label="<?php echo __('Menu','congdongweb'); ?>" aria-controls="main-menu" aria-expanded="false">

		  <?php echo get_congdongweb_icon('icon-menu'); ?>

		  <?php if(congdongweb_option('menu_icon_title')) echo '<span class="menu-title uppercase hide-for-small">'.__('Menu','congdongweb').'</span>'; ?>
		</a>
	<?php if($icon_style) { ?> </div> <?php } ?>
</li>
