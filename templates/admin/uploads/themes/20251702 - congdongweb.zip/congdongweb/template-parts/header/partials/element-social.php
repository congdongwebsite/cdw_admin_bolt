<?php
/**
 * Social element.
 *
 * @package          Congdongweb\Templates
 * @congdongweb-version 3.16.0
 */

?>
<li class="html header-social-icons ml-0">
	<?php echo do_shortcode('[follow defaults="true" style="'.congdongweb_option('follow_style').'"]')?>
</li>
