<?php
/**
 * Server-side rendering of the `congdongweb/uxbuilder` block.
 *
 * @package Congdongweb
 */

/**
 * Registers the `congdongweb/uxbuilder` component and block. This block doesn't
 * need a render function because it only contains raw HTML and shortcodes.
 */
function congdongweb_register_uxbuilder_block() {
	$path     = __DIR__ . '/block.json';
	$metadata = json_decode( file_get_contents( $path ), true );

	register_block_type(
		$metadata['name'],
		$metadata
	);
}
add_action( 'init', 'congdongweb_register_uxbuilder_block' );
