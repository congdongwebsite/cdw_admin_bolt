<?php

/**
 * Congdongweb_INC_Admin class.
 *
 * @package Flatsome
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

/**
 * The Flatsome Envato.
 */
final class Congdongweb_INC_Admin
{

	/**
	 * The single class instance.
	 *
	 * @var object
	 */
	private static $instance = null;

	/**
	 * Main Congdongweb_INC_Admin instance
	 *
	 * @return Congdongweb_INC_Admin.
	 */
	public static function instance()
	{
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * The Flatsome_Registration instance.
	 *
	 * @var Flatsome_Registration
	 */
	public $registration = null;

	/**
	 * Setup instance properties
	 *
	 * @param Congdongweb $registration The Congdongweb instance.
	 */
	public function __construct()
	{
		$slug = congdongweb_theme_key();

		$this->registration = new Congdongweb_Base_Registration($slug);

		add_action('wp_ajax_congdongweb_registration_dismiss_notice', array($this->registration, 'dismiss_notice'));
	}
}
