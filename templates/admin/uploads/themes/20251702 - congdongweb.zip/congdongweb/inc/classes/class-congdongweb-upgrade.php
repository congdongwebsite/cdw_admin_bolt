<?php
/**
 * Handles congdongweb option upgrades
 *
 * @author     UX Themes
 * @category   Class
 * @package    Congdongweb/Classes
 * @since      3.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Congdongweb_Upgrade
 */
class Congdongweb_Upgrade {

	/**
	 * Holds congdongweb DB version
	 *
	 * @var string
	 */
	private $db_version;

	/**
	 * Holds congdongweb current running parent theme version
	 *
	 * @var string
	 */
	private $running_version;

	/**
	 * Holds is upgrade completed
	 *
	 * @var bool
	 */
	private $is_upgrade_completed = false;

	/**
	 * Holds update callback that need to be run per version
	 *
	 * @var array
	 */
	private $updates = array(
		'3.4.0'  => array(
			'update_340',
		),
	);

	/**
	 * Congdongweb_Upgrade Class constructor
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'check_version' ), 5, 0 );
	}

	/**
	 * Check Congdongweb version and run the updater if required.
	 */
	public function check_version() {
		$theme                 = wp_get_theme( get_template() );
		$this->db_version      = get_theme_mod( 'congdongweb_db_version', '3.0.0' );
		$this->running_version = $theme->version;

		// If current version is new.
		if ( version_compare( $this->db_version, $this->running_version, '<' ) ) {
			$this->update();
		}
	}

	/**
	 * Push all needed updates
	 */
	private function update() {
		if ( version_compare( $this->db_version, $this->highest_update_version(), '<' ) ) {
			try {
				foreach ( $this->updates as $version => $update_callbacks ) {
					if ( version_compare( $this->db_version, $version, '<' ) ) {

						// Run all callbacks.
						foreach ( $update_callbacks as $update_callback ) {
							if ( method_exists( $this, $update_callback ) ) {
								$this->$update_callback();
							} elseif ( function_exists( $update_callback ) ) {
								$update_callback();
							}
						}
					}
				}

				$this->update_db_version();
			} catch ( Exception $e ) {
				error_log( $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
			}
		} else {
			$this->update_db_version();
		}
	}

	/**
	 * Retrieve the version number of the highest update available.
	 *
	 * @return string Version number
	 */
	private function highest_update_version() {
		return array_reduce( array_keys( $this->updates ), function ( $highest, $current ) {
			return version_compare( $highest, $current, '>' ) ? $highest : $current;
		}, '1.0.0' );
	}

	/**
	 * Performs upgrades to Congdongweb 3.4.0
	 */
	private function update_340() {
		$portfolio_archive_filter = get_theme_mod( 'portfolio_archive_filter' );
		if ( empty( $portfolio_archive_filter ) ) {
			set_theme_mod( 'portfolio_archive_filter', 'left' );
		}
	}

	/**
	 * Set the DB version to the current running version.
	 * Should only be called when all upgrades are performed.
	 */
	private function update_db_version() {
		set_theme_mod( 'congdongweb_db_version', $this->running_version );
	}
}

new Congdongweb_Upgrade();
