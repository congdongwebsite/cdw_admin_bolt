<?php

/**
 * CongDongWeb_Registration class.
 *
 * @package CongDongWeb
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * The UX Themes API.
 */
final class CDW_API
{

    /**
     * Setup instance.
     */
    public function __construct()
    {
        add_filter('http_headers_useragent', array($this, 'http_headers_useragent'), 10, 2);
    }

    /**
     * Filters the user agent value sent with an HTTP request.
     *
     * @param string $useragent WordPress user agent string.
     * @param string $url The request URL.
     * @return string
     */
    public function http_headers_useragent($useragent, $url = '')
    {
        if (strpos($url, CDW_API_URL) !== false) {
            $theme = wp_get_theme(get_template());
            return 'CongDongWeb/' . $theme->get('Version') . '; ' . $useragent;
        }
        return $useragent;
    }

    /**
     * Sends a request to the CongDongWeb Account API.
     *
     * @param string $path    REST API path.
     * @param string $context REST API path.
     * @param array  $args    Request arguments.
     * @return array|WP_error
     */
    public function send_request($path, $context = null, $args = array())
    {
        $args = array_merge_recursive($args, array(
            'timeout' => 60,
            'headers' => array(
                'Referer' => $this->get_site_url(),
            ),
        ));
        $url      = esc_url_raw(CDW_API_URL . $path);
        $response = wp_remote_post($url, $args);
        $status   = wp_remote_retrieve_response_code($response);
        $headers  = wp_remote_retrieve_headers($response);
        $body     = wp_remote_retrieve_body($response);
        $data     = (array) json_decode($body, true);

        if (is_wp_error($response) || !$data['success']) {
            return $this->get_error($response, $context, $data);
        }
        return $data['data'];
    }

    /**
     * Returns the raw site URL.
     *
     * @return string
     */
    protected function get_site_url()
    {
        global $wpdb;

        $row = $wpdb->get_row("SELECT option_value FROM $wpdb->options WHERE option_name = 'siteurl' LIMIT 1");

        if (is_object($row)) {
            return $row->option_value;
        }

        return '';
    }

    /**
     * Returns a proper error for a HTTP status code.
     *
     * @param WP_Error $error   The original error.
     * @param string   $context A context.
     * @param array    $data    Optional data.
     * @return WP_Error
     */
    public function get_error($error, $context = null, $data = array())
    {
        if (is_array($data) && isset($data['success']) && !$data['success']) {
            return new WP_Error(400, $data['msg'] ?? '', $data);
        }
        $status        = (int) $error->get_error_code();
        $account_attrs = ' href="' . esc_url_raw(CDW_API_URL) . '" target="_blank" rel="noopener noreferrer"';


        switch ($status) {
            case 400:
                return $error;
            case 403:
                return $error;
            case 404:
                return $error;
            case 409:
                // translators: %s: License manager link attributes.
                return new WP_Error($status, sprintf(__('The purchase code is already registered on another site. Please go to <a%s>your account</a> and manage your licenses.', 'congdongweb'), $account_attrs), $data);
            case 410:
                return new WP_Error($status, __('The requested resource no longer exists.', 'congdongweb'), $data);
            case 417:
                return new WP_Error($status, __('No domain was sent with the request.', 'congdongweb'), $data);
            case 422:
                return new WP_Error($status, __('Unable to parse the domain for your site.', 'congdongweb'), $data);
            case 423:
                return new WP_Error($status, __('The requested resource has been locked.', 'congdongweb'), $data);
            case 429:
                return new WP_Error($status, __('Sorry, the API is overloaded.', 'congdongweb'), $data);
            case 503:
                return new WP_Error($status, __('Sorry, the API is unavailable at the moment.', 'congdongweb'), $data);
            default:
                return $error;
        }
    }
}
