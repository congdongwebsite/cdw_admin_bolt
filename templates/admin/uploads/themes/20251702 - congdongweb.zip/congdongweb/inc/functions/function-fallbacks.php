<?php

// Fallbacks
function congdongweb_add_fallbacks () {
	_deprecated_function( __FUNCTION__, '3.16' );
}
