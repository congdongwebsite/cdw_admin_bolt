<?php

/**
 * Adds site status tests for Congdongweb registration.
 *
 * @param array $tests An associative array of tests.
 * @return array
 */
function congdongweb_site_status_tests( $tests ) {
	$tests['direct']['congdongweb_registration'] = array(
		'label' => __( 'Congdongweb registration', 'congdongweb' ),
		'test'  => 'congdongweb_site_health_registration_test',
	);

	return $tests;
}
add_filter( 'site_status_tests', 'congdongweb_site_status_tests' );

/**
 * Performs the registration status test.
 *
 * @return array
 */
function congdongweb_site_health_registration_test() {

	$result = array(
		'test'        => 'congdongweb_registration',
		'label'       => __( 'Congdongweb is registered', 'congdongweb' ),
		'status'      => 'good',
		'badge'       => array(
			'label' => __( 'Security', 'congdongweb' ),
			'color' => 'blue',
		),
		'description' => sprintf( '<p>%s</p>', __( 'Register Congdongweb to receive updates.', 'congdongweb' ) ),
		'actions'     => '',
	);

	return $result;
}
