<?php

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'textfield',
	'settings'     => 'nav_position',
	'label'       => __( 'Nav Position', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'default'     => '',
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'textfield',
	'settings'     => 'search_pos',
	'label'       => __( 'Search Position', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'default'     => '',
));