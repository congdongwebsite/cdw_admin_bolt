<?php
add_action('admin_notices', 'congdongweb_maintenance_admin_notice');

function congdongweb_maintenance_admin_notice()
{
	$screen       = get_current_screen();
	$errors       = congdongweb_inc_admin()->registration->get_errors();
	if (
		count($errors) &&
		congdongweb_inc_admin()->registration->get_option('show_notice') &&
		$screen->id !== 'toplevel_page_congdongweb-panel'
	) {
?>
		<div id="congdongweb-notice" class="notice notice-warning notice-alt is-dismissible">
			<h3 class="notice-title"><?php esc_html_e('Thông báo từ Cộng Đồng Web', 'congdongweb'); ?></h3>
			<?php foreach ($errors as $error) : ?>
				<?php echo wpautop($error); ?>
			<?php endforeach; ?>
			<script>
				jQuery(function($) {
					$('#congdongweb-notice').on('click', '.notice-dismiss', function() {
						$.post('<?php echo admin_url('admin-ajax.php?action=congdongweb_registration_dismiss_notice') ?>');
					});
				});
			</script>
		</div>
<?php
	}
}
