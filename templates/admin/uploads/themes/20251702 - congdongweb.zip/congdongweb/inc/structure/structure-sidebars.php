<?php

function congdongweb_sidebar_classes(){

   echo implode(' ',  apply_filters( 'congdongweb_sidebar_class', array() ) );
}


function congdongweb_add_sidebar_class($classes){
	//$classes[] = 'col-divided';
	//$classes[] = 'widgets-boxed';

	return $classes;
}

add_filter('congdongweb_sidebar_class','congdongweb_add_sidebar_class', 10);

/**
 * Renders the sidebar menu header content.
 */
function congdongweb_mobile_sidebar_top_content() {
	if ( $top_content = get_theme_mod( 'mobile_sidebar_top_content' ) ) {
		echo '<div class="sidebar-menu-top-content">';
		echo do_shortcode( $top_content );
		echo '</div>';
	}
}

add_action( 'congdongweb_before_sidebar_menu_elements', 'congdongweb_mobile_sidebar_top_content' );
