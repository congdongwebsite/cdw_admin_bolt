<?php // @codingStandardsIgnoreLine


namespace Congdongweb\Extensions;

defined( 'ABSPATH' ) || exit;


global $extensions_url;
require $extensions_url . '/congdongweb-swatches/includes/class-swatches.php';

congdongweb_swatches();

