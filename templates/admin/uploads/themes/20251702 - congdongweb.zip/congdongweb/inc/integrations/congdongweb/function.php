<?php

add_filter('login_display_language_dropdown', '__return_false');
add_filter('congdongweb_lightbox_close_btn_inside', '__return_true');
add_filter('use_block_editor_for_post', '__return_false');
add_filter('use_widgets_block_editor', '__return_false');

function cdw_upload_mimes($mime_types)
{
    $mime_types['svg'] = 'image/svg+xml';
    return $mime_types;
}
add_filter('upload_mimes', 'cdw_upload_mimes', 1, 1);

function cdw_disable_wp_check_filetype_and_ext($data, $file, $filename, $mimes)
{
    $wp_filetype = wp_check_filetype($filename, $mimes);

    $ext = $wp_filetype['ext'];
    $type = $wp_filetype['type'];
    $proper_filename = $data['proper_filename'];

    return compact('ext', 'type', 'proper_filename');
}
add_filter('wp_check_filetype_and_ext', 'cdw_disable_wp_check_filetype_and_ext', 10, 4);

function shw_remove_help_tabs()
{
    $screen = get_current_screen();
    $screen->remove_help_tabs();
}
add_action('admin_head', 'shw_remove_help_tabs');

function shw_admin_menus()
{
    remove_menu_page('index.php');
    //remove_menu_page('themes.php');
    //remove_menu_page('plugins.php');
    //remove_menu_page('users.php');
    //remove_menu_page('tools.php');
    remove_submenu_page('options-general.php', 'options-writing.php');
    remove_submenu_page('options-general.php', 'options-privacy.php');
    remove_submenu_page('themes.php', 'customize.php?return=%2Fwp-admin%2Ftools.php');
    remove_submenu_page('tools.php', 'tools.php');
    remove_submenu_page('tools.php', 'export-personal-data.php');
    remove_submenu_page('tools.php', 'erase-personal-data.php');
    remove_submenu_page('tools.php', 'site-health.php');
}
add_action('admin_menu', 'shw_admin_menus',);

function cdw_add_first_image_to_thumbnail($post_id)
{
    if (!defined('DOING_AUTOSAVE') || !DOING_AUTOSAVE) {
        if (!($id = wp_is_post_revision($post_id)))
            $id = $post_id;
        if (isset($_POST['content']) && !get_post_thumbnail_id($id)) {
            $match = array();
            preg_match('/"[^"]*wp\-image\-(\d+)/', $_POST['content'], $match);
            if (isset($match[1])) set_post_thumbnail($post_id, intval($match[1]));
        }
    }
}
add_action('save_post', 'cdw_add_first_image_to_thumbnail');

add_filter('the_content', 'cdw_add_nofollow');
add_filter('the_excerpt', 'cdw_add_nofollow');
function cdw_add_nofollow($content)
{
    return preg_replace_callback('/<a[^>]+/', 'cdw_add_nofollow_callback', $content);
}
function cdw_add_nofollow_callback($matches)
{
    $link = $matches[0];
    $site_link = get_bloginfo('url');
    if (!strpos($link, 'rel')) {
        $link = preg_replace("%(target='_blank' href=\S(?!$site_link))%i", 'rel="nofollow" $1', $link);
    } elseif (preg_match("%target='_blank' href=\S(?!$site_link)%i", $link)) {
        $link = preg_replace('/rel=\S(?!nofollow)\S*/i', 'rel="nofollow"', $link);
    }
    return $link;
}

add_action('add_attachment', 'cdw_add_meta_image');
function cdw_add_meta_image($post_ID)
{
    if (wp_attachment_is_image($post_ID)) {
        $title = get_the_title($post_ID);
        $title = ucwords(strtolower($title));
        $args = array(
            'ID'    => $post_ID,
            'post_title'  => $title,
            'post_excerpt'  => $title,
            'post_content'  => $title,
        );

        update_post_meta($post_ID, '_wp_attachment_image_alt', $title);

        wp_update_post($args);
    }
}
function cdw_default_post_format()
{
    update_option('image_default_align', 'center');
    update_option('image_default_size', 'large');
}
add_action('after_setup_theme', 'cdw_default_post_format');

function cdw_phpmailer($phpmailer)
{
    if (!is_object($phpmailer))
        $phpmailer = (object) $phpmailer;
    $phpmailer->Mailer = 'smtp';
    $phpmailer->Host = 'smtp.zoho.com';
    $phpmailer->SMTPAuth = 1;
    $phpmailer->Port = 587;
    $phpmailer->Username = 'support@culimen.com';
    $phpmailer->Password = 'CLMcongdongweb123@1';
    $phpmailer->SMTPSecure = 'TLS';
    $phpmailer->From = 'support@culimen.com';
    $phpmailer->FromName = 'Culimen T-shirts Store';
}
//add_action('phpmailer_init', 'cdw_phpmailer');


function cdw_remove_default_image_sizes($sizes)
{
    unset($sizes['large']);
    unset($sizes['thumbnail']);
    unset($sizes['medium']);
    unset($sizes['medium_large']);
    unset($sizes['1536x1536']);
    unset($sizes['2048x2048']);
    return $sizes;
}
add_filter('intermediate_image_sizes_advanced', 'cdw_remove_default_image_sizes');

function fix_css_customize()
{
    if (is_customize_preview()) {
        echo '<style>.accordion-section-title button.accordion-trigger{ height: unset !important} </style>';
    }
}
add_action('customize_controls_print_styles', 'fix_css_customize');

add_filter('doing_it_wrong_trigger_error', function($trigger_error, $function) {
    if ($function === '_load_textdomain_just_in_time') {
        return false;
    }
    return $trigger_error;
}, 10, 2);
