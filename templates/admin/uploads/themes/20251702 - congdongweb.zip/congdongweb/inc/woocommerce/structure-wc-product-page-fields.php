<?php

add_action( 'wc_cpdf_init', 'wc_custom_product_data_fields', 10, 0 );

if ( ! function_exists( 'wc_custom_product_data_fields' ) ) {
	/**
	 * Custom WooCommerce product fields
	 *
	 * @return array
	 */
	function wc_custom_product_data_fields() {

		$custom_product_data_fields = array();

		$custom_product_data_fields['ux_product_layout_tab'] = array(
			array(
				'tab_name' => __( 'Product layout', 'congdongweb' ),
			),
			array(
				'id'          => '_product_block',
				'type'        => 'select',
				'label'       => __( 'Custom product layout', 'congdongweb' ),
				'style'       => 'width:100%;height:140px;',
				'description' => __( 'Choose a custom product block layout for this product.', 'congdongweb' ),
				'desc_tip'    => true,
				'options'     => congdongweb_get_block_list_by_id( array( 'option_none' => '-- None --' ) ),
			),
			array(
				'id'          => '_top_content',
				'type'        => 'textarea',
				'label'       => __( 'Top Content', 'congdongweb' ),
				'style'       => 'width:100%;height:140px;',
				'description' => __( 'Enter content that will show after the header and before the product. Shortcodes are allowed', 'congdongweb' ),
			),
			array(
				'id'          => '_bottom_content',
				'type'        => 'textarea',
				'label'       => __( 'Bottom Content', 'congdongweb' ),
				'style'       => 'width:100%;height:140px;',
				'description' => __( 'Enter content that will show after the product info. Shortcodes are allowed', 'congdongweb' ),
			),
		);

		$custom_product_data_fields['ux_extra_tab'] = array(
			array(
				'tab_name' => __( 'Extra', 'congdongweb' ),
			),
			array(
				'id'          => '_bubble_new',
				'type'        => 'select',
				'label'       => __( 'Custom Bubble', 'congdongweb-admin' ),
				'description' => __( 'Enable a custom bubble on this product.', 'congdongweb' ),
				'desc_tip'    => true,
				'options'     => array(
					''      => 'Disabled',
					'"yes"' => 'Enabled',
				),
			),
			array(
				'id'          => '_bubble_text',
				'type'        => 'text',
				'label'       => __( 'Custom Bubble Title', 'congdongweb-admin' ),
				'placeholder' => __( 'NEW', 'congdongweb-admin' ),
				'class'       => 'large',
				'description' => __( 'Field description.', 'congdongweb-admin' ),
				'desc_tip'    => true,
			),
			array(
				'type' => 'divider',
			),
			array(
				'id'          => '_custom_tab_title',
				'type'        => 'text',
				'label'       => __( 'Custom Tab Title', 'congdongweb-admin' ),
				'class'       => 'large',
				'description' => __( 'Field description.', 'congdongweb-admin' ),
				'desc_tip'    => true,
			),
			array(
				'id'          => '_custom_tab',
				'type'        => 'textarea',
				'label'       => __( 'Custom Tab Content', 'congdongweb' ),
				'style'       => 'width:100%;height:140px;',
				'description' => __( 'Enter content for custom product tab here. Shortcodes are allowed', 'congdongweb' ),
			),
			array(
				'type' => 'divider',
			),
			array(
				'id'          => '_product_video',
				'type'        => 'text',
				'placeholder' => 'https://www.youtube.com/watch?v=Ra_iiSIn4OI',
				'label'       => __( 'Product Video', 'congdongweb' ),
				'style'       => 'width:100%;',
				'description' => __( 'Enter a Youtube or Vimeo Url of the product video here. We recommend uploading your video to Youtube.', 'congdongweb' ),
			),
			array(
				'id'          => '_product_video_size',
				'type'        => 'text',
				'label'       => __( 'Product Video Size', 'congdongweb-admin' ),
				'placeholder' => __( '900x900', 'congdongweb-admin' ),
				'class'       => 'large',
				'description' => __( 'Set Product Video Size.. Default is 900x900. (Width X Height)', 'congdongweb-admin' ),
				'desc_tip'    => true,
			),
			array(
				'id'          => '_product_video_placement',
				'type'        => 'select',
				'label'       => __( 'Product Video Placement', 'congdongweb-admin' ),
				'description' => __( 'Select where you want to display product video.', 'congdongweb' ),
				'desc_tip'    => true,
				'options'     => array(
					''    => 'Lightbox (Default)',
					'tab' => 'New Tab',
				),
			),
		);

		return $custom_product_data_fields;
	}
}
