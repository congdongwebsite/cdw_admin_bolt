<?php

/**
 * CongDongWeb Theme Setup Wizard Class
 *
 * Takes new users through some basic steps to setup their ThemeForest theme.
 *
 * @author      dtbaker
 * @author      vburlak
 * @package     congdongweb_wizard
 * @version     1.1.7
 *
 * Based off the WooThemes installer.
 *
 */
if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('CongDongWeb_Theme_Setup_Wizard')) {
	/**
	 * CongDongWeb_Theme_Setup_Wizard class
	 */
	class CongDongWeb_Theme_Setup_Wizard
	{

		/**
		 * The class version number.
		 *
		 * @since 1.1.1
		 * @access private
		 *
		 * @var string
		 */
		protected $version = '1.1.9';

		/** @var string Current theme name, used as namespace in actions. */
		protected $theme_name = '';

		/** @var string Current Step */
		protected $step   = '';

		/** @var array Steps for the setup wizard */
		protected $steps  = array();

		/**
		 * Relative plugin url for this plugin folder, used when enquing scripts
		 *
		 * @since 1.1.2
		 *
		 * @var string
		 */
		protected $plugin_url = '';

		/**
		 * The slug name to refer to this menu
		 *
		 * @since 1.1.1
		 *
		 * @var string
		 */
		protected $page_slug;

		/**
		 * TGMPA instance storage
		 *
		 * @var object
		 */
		protected $tgmpa_instance;

		/**
		 * TGMPA Menu slug
		 *
		 * @var string
		 */
		protected $tgmpa_menu_slug = 'tgmpa-install-plugins';

		/**
		 * TGMPA Menu url
		 *
		 * @var string
		 */
		protected $tgmpa_url = 'themes.php?page=tgmpa-install-plugins';

		/**
		 * The slug name for the parent menu
		 *
		 * @since 1.1.2
		 *
		 * @var string
		 */
		protected $page_parent;

		/**
		 * Complete URL to Setup Wizard
		 *
		 * @since 1.1.2
		 *
		 * @var string
		 */
		protected $page_url;


		/**
		 * Holds the current instance of the theme manager
		 *
		 * @since 1.1.3
		 * @var CongDongWeb_Theme_Setup_Wizard
		 */
		private static $instance = null;

		/**
		 * @since 1.1.3
		 *
		 * @return CongDongWeb_Theme_Setup_Wizard
		 */
		public static function get_instance()
		{
			if (!self::$instance) {
				self::$instance = new self;
			}

			return self::$instance;
		}

		/**
		 * A dummy constructor to prevent this class from being loaded more than once.
		 *
		 * @see CongDongWeb_Theme_Setup_Wizard::instance()
		 *
		 * @since 1.1.1
		 * @access private
		 */
		public function __construct()
		{
			$this->init_globals();
			$this->init_actions();
		}

		/**
		 * Get the site logo URL.
		 *
		 * @see CongDongWeb_Theme_Setup_Wizard::instance()
		 *
		 * @since 3.15.2
		 * @access public
		 */
		public function get_site_logo()
		{
			$image_url = get_template_directory_uri() . '/assets/img/logo.png';
			$site_logo = do_shortcode(get_theme_mod('site_logo', $image_url));
			if (is_numeric($site_logo)) {
				$image_src = wp_get_attachment_image_src($site_logo, 'large');
				if (!empty($image_src)) {
					$image_url = $image_src[0];
				}
			} else if (is_string($site_logo)) {
				$image_url = $site_logo;
			}
			return apply_filters('congdongweb_setup_logo_image', $image_url);
		}

		/**
		 * Get the default style. Can be overriden by theme init scripts.
		 *
		 * @see CongDongWeb_Theme_Setup_Wizard::instance()
		 *
		 * @since 1.1.9
		 * @access public
		 */
		public function get_header_logo_width()
		{
			return '200px';
		}

		public function register()
		{
			$slug = congdongweb_theme_key();

			delete_option('flatsome_wup_buyer');
			delete_option('flatsome_wup_sold_at');
			delete_option('flatsome_wup_purchase_code');
			delete_option('flatsome_wup_supported_until');
			delete_option('flatsome_wup_errors');
			delete_option('flatsome_wup_attempts');
			delete_option('flatsome_update_cache');
			delete_option('flatsome_wupdates');
			delete_option('widget_flatsome_recent_posts');

			delete_option('_transient__flatsome_activation_redirect');
			delete_option('_transient_timeout_global_styles_svg_filters_flatsome-child');
			delete_option('_transient_global_styles_svg_filters_flatsome-child');
			delete_option('_transient_timeout_global_styles_flatsome-child');
			delete_option('_transient_global_styles_flatsome-child');


			$theme_mods_flatsome = get_option('theme_mods_flatsome');
			if (!empty($theme_mods_flatsome)) {
				update_option('theme_mods_' . $slug, $theme_mods_flatsome);
			}

			$slug = congdongweb_theme_key(basename(get_stylesheet_directory()));
			$theme_mods_flatsome_child = get_option('theme_mods_flatsome-child');
			if (is_child_theme() && !empty($theme_mods_flatsome_child)) {
				update_option('theme_mods_' . $slug, $theme_mods_flatsome_child);
			}
			echo '<p class="success">+ Đã chuyển các tùy chọn của theme cũ sang theme mới.</p>';

			delete_option('theme_mods_flatsome-child');
			delete_option('theme_mods_flatsome');

			echo '<p class="error">+ Đã xóa 1 số tùy chỉnh cũ nếu có</p>';
			update_option('WPLANG', 'vi');
			update_option('timezone_string', 'Asia/Ho_Chi_Minh');
			update_option('gmt_offset', '7');
			update_option('date_format', 'D, d/m/Y');
			update_option('time_format', 'H:i:s');
			update_option('start_of_week', 1);
			echo '<p class="success">+ Đã cập nhật thông tin ngày giờ.</p>';
			update_option(congdongweb_theme_key() . '_purchase_code', 'E88485932BDB822B2CA53AC8BC11F');
			echo '<p class="success">+ Đã cập nhật key dùng chung.</p>';
		}
		public function register_option_default()
		{
			$options = get_theme_mods();
			set_theme_mod('congdongweb_fallback', 0);

			if (!isset($options['topbar_elements_left'])) set_theme_mod('topbar_elements_left', congdongweb_topbar_elements_left());
			if (!isset($options['topbar_elements_right'])) set_theme_mod('topbar_elements_right', congdongweb_topbar_elements_right());
			if (!isset($options['header_elements_left'])) set_theme_mod('header_elements_left', congdongweb_header_elements_left());
			if (!isset($options['header_elements_right'])) set_theme_mod('header_elements_right', congdongweb_header_elements_right());

			if (!isset($options['header_elements_bottom_left'])) set_theme_mod('header_elements_bottom_left', congdongweb_header_elements_bottom_left());
			if (!isset($options['header_elements_bottom_center'])) set_theme_mod('header_elements_bottom_center', congdongweb_header_elements_bottom_center());
			if (!isset($options['header_elements_bottom_right'])) set_theme_mod('header_elements_bottom_right', congdongweb_header_elements_bottom_right());

			if (!isset($options['header_mobile_elements_left'])) set_theme_mod('header_mobile_elements_left', congdongweb_header_mobile_elements_left());
			if (!isset($options['header_mobile_elements_right'])) set_theme_mod('header_mobile_elements_right', congdongweb_header_mobile_elements_right());
			if (!isset($options['header_mobile_elements_top'])) set_theme_mod('header_mobile_elements_top', congdongweb_header_mobile_elements_top());

			if (!isset($options['mobile_sidebar'])) set_theme_mod('mobile_sidebar', congdongweb_header_mobile_sidebar());
			if (!isset($options['product_layout'])) set_theme_mod('product_layout', congdongweb_product_layout());
			if (!congdongweb_is_upgrading()) set_theme_mod('payment_icons_placement', 'footer');

			// Set follow icons
			if (!isset($options['follow_twitter'])) set_theme_mod('follow_twitter', 'http://url');
			if (!isset($options['follow_facebook'])) set_theme_mod('follow_facebook', 'http://url');
			if (!isset($options['follow_instagram'])) set_theme_mod('follow_instagram', 'http://url');
			if (!isset($options['follow_email'])) set_theme_mod('follow_email', 'your@email');

			$theme    = wp_get_theme(get_template());
			$version  = $theme->get('Version');
			set_theme_mod('congdongweb_version', $version);

			echo '<p class="success">+ Đã cập nhật các tùy chọn</p>';
		}

		public function register_permalink()
		{
			global $wp_rewrite, $is_nginx;

			/** WordPress Administration File API */
			require_once ABSPATH . 'wp-admin/includes/file.php';

			/** WordPress Misc Administration API */
			require_once ABSPATH . 'wp-admin/includes/misc.php';

			$htaccess_update_required = false;

			$home_path           = get_home_path();
			$iis7_permalinks     = iis7_supports_permalinks();
			$permalink_structure = get_option('permalink_structure');

			$index_php_prefix = '';
			$blog_prefix      = '';

			if (!got_url_rewrite()) {
				$index_php_prefix = '/index.php';
			}
			if (
				is_multisite() && !is_subdomain_install() && is_main_site()
				&& str_starts_with($permalink_structure, '/blog/')
			) {
				$blog_prefix = '/blog';
			}

			$permalink_structure = '/%postname%/';
			$permalink_structure = preg_replace('#/+#', '/', '/' . str_replace('#', '', $permalink_structure));
			if ($index_php_prefix && $blog_prefix) {
				$permalink_structure = $index_php_prefix . preg_replace('#^/?index\.php#', '', $permalink_structure);
			} else {
				$permalink_structure = $blog_prefix . $permalink_structure;
			}
			$permalink_structure = sanitize_option('permalink_structure', $permalink_structure);
			$wp_rewrite->set_permalink_structure($permalink_structure);


			$category_base = 'chuyen-muc';
			$category_base = $blog_prefix . preg_replace('#/+#', '/', '/' . str_replace('#', '', $category_base));
			$wp_rewrite->set_category_base($category_base);


			$tag_base = 'the';
			$tag_base = $blog_prefix . preg_replace('#/+#', '/', '/' . str_replace('#', '', $tag_base));
			$wp_rewrite->set_tag_base($tag_base);


			if ($iis7_permalinks) {
				if ((!file_exists($home_path . 'web.config')
						&& win_is_writable($home_path)) || win_is_writable($home_path . 'web.config')
				) {
					$writable = true;
				} else {
					$writable = false;
				}
			} elseif ($is_nginx) {
				$writable = false;
			} else {
				if ((!file_exists($home_path . '.htaccess')
						&& is_writable($home_path)) || is_writable($home_path . '.htaccess')
				) {
					$writable = true;
				} else {
					$writable       = false;
					$existing_rules = array_filter(extract_from_markers($home_path . '.htaccess', 'WordPress'));
					$new_rules      = array_filter(explode("\n", $wp_rewrite->mod_rewrite_rules()));

					$htaccess_update_required = ($new_rules !== $existing_rules);
				}
			}


			$using_index_permalinks = $wp_rewrite->using_index_permalinks();
			$message = __('Đường dẫn tĩnh đã được cập nhật.');

			if (!is_multisite() && $permalink_structure && !$using_index_permalinks) {
				if ($iis7_permalinks) {
					if (!$writable) {
						$message = sprintf(
							__('Bạn vui lòng cập nhật tập tin %s.'),
							'<code>web.config</code>'
						);
					} else {
						$message = sprintf(
							__('Đường dẫn tĩnh đã được cập nhậ. Bạn có thể bỏ quyền ghi tập tin %s!'),
							'<code>web.config</code>'
						);
					}
				} elseif (!$is_nginx && $htaccess_update_required && !$writable) {
					$message = sprintf(
						__('Bạn vui lòng cập nhật tập tin %s.'),
						'<code>.htaccess</code>'
					);
				}
			}
			echo '<p class="success">+ ' . $message . '</p>';
		}
		/**
		 * Setup the class globals.
		 *
		 * @since 1.1.1
		 * @access public
		 */
		public function init_globals()
		{
			$current_theme = wp_get_theme();
			$this->theme_name = strtolower(preg_replace('#[^a-zA-Z]#', '', $current_theme->get('Name')));
			$this->page_slug = apply_filters('congdongweb_theme_setup_wizard_page_slug', 'congdongweb-setup');
			$this->parent_slug = apply_filters($this->theme_name . '_theme_setup_wizard_parent_slug', '');

			//If we have parent slug - set correct url
			if ($this->parent_slug !== '') {
				$this->page_url = 'admin.php?page=' . $this->page_slug;
			} else {
				$this->page_url = 'admin.php?page=' . $this->page_slug;
			}
			$this->page_url = apply_filters($this->theme_name . '_theme_setup_wizard_page_url', $this->page_url);

			// Set plugin URL directory.
			$this->plugin_url = trailingslashit(get_template_directory_uri() . '/inc/admin/congdongweb_setup');
		}

		/**
		 * Setup the hooks, actions and filters.
		 *
		 * @uses add_action() To add actions.
		 * @uses add_filter() To add filters.
		 *
		 * @since 1.1.1
		 * @access public
		 */
		public function init_actions()
		{
			if (apply_filters($this->theme_name . '_enable_setup_wizard', true) && current_user_can('manage_options')) {

				if (!is_child_theme()) {
					add_action('after_switch_theme', array($this, 'switch_theme'));
				}

				if (class_exists('TGM_Plugin_Activation') && isset($GLOBALS['tgmpa'])) {
					add_action('init', array($this, 'get_tgmpa_instanse'), 30);
					add_action('init', array($this, 'set_tgmpa_url'), 40);
				}

				add_action('admin_menu', array($this, 'admin_menus'));
				add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
				add_action('admin_init', array($this, 'admin_redirects'), 30);

				add_action('admin_init', array($this, 'init_wizard_steps'), 30);
				add_action('admin_init', array($this, 'setup_wizard'), 30);
				add_filter('tgmpa_load', array($this, 'tgmpa_load'), 10, 1);
				add_action('wp_ajax_congdongweb_setup_plugins', array($this, 'ajax_plugins'));
				add_action('wp_ajax_congdongweb_setup_content', array($this, 'ajax_content'));
			}

			add_action('upgrader_post_install', array($this, 'upgrader_post_install'), 10, 2);
		}

		/**
		 * After a theme update we clear the setup_complete option. This prompts the user to visit the update page again.
		 *
		 * @since 1.1.8
		 * @access public
		 */
		public function upgrader_post_install($return, $theme)
		{
			if (is_wp_error($return)) {
				return $return;
			}
			if ($theme != get_stylesheet()) {
				return $return;
			}
			update_option('congdongweb_setup_complete', false);

			return $return;
		}
		/**
		 * We determine if the user already has theme content installed. This can happen if swapping from a previous theme or updated the current theme. We change the UI a bit when updating / swapping to a new theme.
		 *
		 * @since 1.1.8
		 * @access public
		 */
		public function is_possible_upgrade()
		{
			return false;
		}
		public function enqueue_scripts()
		{
		}
		public function tgmpa_load($status)
		{
			return is_admin() || current_user_can('install_themes');
		}
		public function switch_theme()
		{
			set_transient('_' . $this->theme_name . '_activation_redirect', 1);
		}

		public function admin_redirects()
		{
			ob_start();

			if (!get_transient('_' . $this->theme_name . '_activation_redirect') || get_option('congdongweb_setup_complete', false)) {
				return;
			}
			delete_transient('_' . $this->theme_name . '_activation_redirect');
			if (congdongweb_is_upgrading()) {
				wp_safe_redirect(admin_url('admin.php?page=congdongweb-panel'));
			} else {
				wp_safe_redirect(admin_url($this->page_url));
			}
			exit;
		}

		/**
		 * Get configured TGMPA instance
		 *
		 * @access public
		 * @since 1.1.2
		 */
		public function get_tgmpa_instanse()
		{
			$this->tgmpa_instance = call_user_func(array(get_class($GLOBALS['tgmpa']), 'get_instance'));
		}

		/**
		 * Update $tgmpa_menu_slug and $tgmpa_parent_slug from TGMPA instance
		 *
		 * @access public
		 * @since 1.1.2
		 */
		public function set_tgmpa_url()
		{

			$this->tgmpa_menu_slug = (property_exists($this->tgmpa_instance, 'menu')) ? $this->tgmpa_instance->menu : $this->tgmpa_menu_slug;
			$this->tgmpa_menu_slug = apply_filters($this->theme_name . '_theme_setup_wizard_tgmpa_menu_slug', $this->tgmpa_menu_slug);

			$tgmpa_parent_slug = (property_exists($this->tgmpa_instance, 'parent_slug') && $this->tgmpa_instance->parent_slug !== 'themes.php') ? 'admin.php' : 'themes.php';

			$this->tgmpa_url = apply_filters($this->theme_name . '_theme_setup_wizard_tgmpa_url', $tgmpa_parent_slug . '?page=' . $this->tgmpa_menu_slug);
		}

		/**
		 * Add admin menus/screens.
		 */
		public function admin_menus()
		{
			add_submenu_page('congdongweb-panel', __('Cài đặt nhanh', 'congdongweb_setup'), __('Cài đặt nhanh', 'congdongweb_setup'), 'manage_options', $this->page_slug,  array($this, $this->page_slug));
		}


		/**
		 * Setup steps.
		 *
		 * @since 1.1.1
		 * @access public
		 * @return array
		 */
		public function init_wizard_steps()
		{

			$this->steps = array(
				'introduction' => array(
					'name'    => __('Introduction', 'congdongweb_setup'),
					'view'    => array($this, 'congdongweb_setup_introduction'),
					'handler' => array($this, 'congdongweb_setup_introduction_save'),
				),
			);

			$this->steps['customize'] = array(
				'name'    => __('Tạo child', 'congdongweb_setup'),
				'view'    => array($this, 'congdongweb_setup_customize'),
				'handler' => '',
			);

			if (class_exists('TGM_Plugin_Activation') && isset($GLOBALS['tgmpa'])) {
				$this->steps['default_plugins'] = array(
					'name' => __('Plugins', 'congdongweb_setup'),
					'view' => array($this, 'congdongweb_setup_default_plugins'),
					'handler' => '',
				);
			}

			$this->steps['design'] = array(
				'name'    => __('Logo', 'congdongweb_setup'),
				'view'    => array($this, 'congdongweb_setup_logo_design'),
				'handler' => array($this, 'congdongweb_setup_logo_design_save'),
			);
			$this->steps['help_support'] = array(
				'name'    => __('Hỗ trợ', 'congdongweb_setup'),
				'view'    => array($this, 'congdongweb_setup_help_support'),
				'handler' => '',
			);
			$this->steps['next_steps'] = array(
				'name'    => __('Xong!', 'congdongweb_setup'),
				'view'    => array($this, 'congdongweb_setup_ready'),
				'handler' => '',
			);


			$this->steps = apply_filters($this->theme_name . '_theme_setup_wizard_steps', $this->steps);
		}

		/**
		 * Show the setup wizard
		 */
		public function setup_wizard()
		{
			if (empty($_GET['page']) || $this->page_slug !== $_GET['page']) {
				return;
			}
			ob_end_clean();

			$this->step = isset($_GET['step']) ? sanitize_key($_GET['step']) : current(array_keys($this->steps));

			wp_register_script('jquery-blockui', $this->plugin_url . 'js/jquery.blockUI.js', array('jquery'), '2.70', true);
			wp_register_script('congdongweb-setup', $this->plugin_url . 'js/congdongweb-setup.js', array('jquery', 'jquery-blockui'), $this->version);
			wp_localize_script('congdongweb-setup', 'congdongweb_setup_params', array(
				'tgm_plugin_nonce'            => array(
					'update' => wp_create_nonce('tgmpa-update'),
					'install' => wp_create_nonce('tgmpa-install'),
				),
				'tgm_bulk_url' => admin_url($this->tgmpa_url),
				'ajaxurl' => admin_url('admin-ajax.php'),
				'wpnonce' => wp_create_nonce('congdongweb_setup_nonce'),
				'verify_text' => __('...verifying', 'congdongweb_setup'),
			));

			//wp_enqueue_style( 'congdongweb_wizard_admin_styles', $this->plugin_url . '/css/admin.css', array(), $this->version );
			wp_enqueue_style('congdongweb-setup', $this->plugin_url . 'css/congdongweb-setup.css', array('wp-admin', 'dashicons', 'install'), $this->version);

			//enqueue style for admin notices
			wp_enqueue_style('wp-admin');

			wp_enqueue_media();
			wp_enqueue_script('media');

			ob_start();
			$this->setup_wizard_header();
			$this->setup_wizard_steps();
			$show_content = true;
			echo '<div class="congdongweb-setup-content">';
			if (!empty($_REQUEST['save_step']) && isset($this->steps[$this->step]['handler'])) {
				$show_content = call_user_func($this->steps[$this->step]['handler']);
			}
			if ($show_content) {
				$this->setup_wizard_content();
			}
			echo '</div>';
			$this->setup_wizard_footer();
			exit;
		}

		public function get_step_link($step)
		{
			return  add_query_arg('step', $step, admin_url('admin.php?page=' . $this->page_slug));
		}
		public function get_next_step_link()
		{
			$keys = array_keys($this->steps);
			return add_query_arg('step', $keys[array_search($this->step, array_keys($this->steps)) + 1], remove_query_arg('translation_updated'));
		}

		/**
		 * Setup Wizard Header
		 */
		public function setup_wizard_header()
		{
?>
			<!DOCTYPE html>
			<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

			<head>
				<meta name="viewport" content="width=device-width" />
				<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
				<title><?php _e('Trình cài đặt nhanh', 'congdongweb_setup'); ?></title>
				<?php wp_print_scripts('congdongweb-setup'); ?>
				<?php do_action('admin_print_styles'); ?>
				<?php do_action('admin_print_scripts'); ?>
				<?php //do_action( 'admin_head' ); 
				?>
			</head>

			<body class="congdongweb-setup wp-core-ui">
				<h1 id="wc-logo">
					<?php
					$image_url = $this->get_site_logo();
					if ($image_url) {
						$image = '<img class="site-logo" src="%s" alt="%s" style="width:%s; height:auto" />';
						printf(
							$image,
							$image_url,
							get_bloginfo('name'),
							$this->get_header_logo_width()
						);
					} ?>
				</h1>
			<?php
		}

		/**
		 * Setup Wizard Footer
		 */
		public function setup_wizard_footer()
		{
			?>
				<a class="wc-return-to-dashboard" href="<?php echo esc_url(admin_url()); ?>"><?php _e('Trở về trang quản trị', 'congdongweb_setup'); ?></a>
			</body>
			<?php
			@do_action('admin_footer');
			do_action('admin_print_footer_scripts');
			?>

			</html>
		<?php
		}

		/**
		 * Output the steps
		 */
		public function setup_wizard_steps()
		{
			$ouput_steps = $this->steps;
			array_shift($ouput_steps);
		?>
			<ol class="congdongweb-setup-steps">
				<?php foreach ($ouput_steps as $step_key => $step) : ?>
					<li class="<?php
								$show_link = false;
								if ($step_key === $this->step) {
									echo 'active';
								} elseif (array_search($this->step, array_keys($this->steps)) > array_search($step_key, array_keys($this->steps))) {
									echo 'done';
									$show_link = true;
								}
								?>"><?php
									if ($show_link) {
									?>
							<a href="<?php echo esc_url($this->get_step_link($step_key)); ?>"><?php echo esc_html($step['name']); ?></a>
						<?php
									} else {
										echo esc_html($step['name']);
									}
						?>
					</li>
				<?php endforeach; ?>
			</ol>
			<?php
		}

		/**
		 * Output the content for the current step
		 */
		public function setup_wizard_content()
		{
			isset($this->steps[$this->step]) ? call_user_func($this->steps[$this->step]['view']) : false;
		}

		/**
		 * Introduction step
		 */
		public function congdongweb_setup_introduction()
		{
			if ($this->is_possible_upgrade()) {
			?>
				<h1><?php printf(__('Trình cài đặt nhanh %s.'), wp_get_theme()); ?></h1>
				<p><?php _e('It looks like you may have recently upgraded to this theme. Great! This setup wizard will help ensure all the default settings are correct. It will also show some information about your new website and support options.'); ?></p>
				<p class="congdongweb-setup-actions step">
					<a href="<?php echo esc_url($this->get_next_step_link()); ?>" class="button-primary button button-large button-next"><?php _e('Let\'s Go!'); ?></a>
					<a href="<?php echo esc_url(wp_get_referer() && !strpos(wp_get_referer(), 'update.php') ? wp_get_referer() : admin_url('')); ?>" class="button button-large"><?php _e('Not right now'); ?></a>
				</p>
			<?php
			} else if (!get_option('congdongweb_setup_complete', false)) {
			?>
				<h1><?php printf(__('Trình cài đặt nhanh %s.'), wp_get_theme()); ?></h1>
				<p class="lead success"><?php _e('Bạn đã hoàn tất cài đặt!.'); ?></p>

				<p class="congdongweb-setup-actions step">
					<a href="<?php echo esc_url($this->get_next_step_link()); ?>" class="button-primary button button-next button-large"><?php _e('Cài đặt lại'); ?></a>
					<a href="<?php echo admin_url('admin.php?page=congdongweb-panel'); ?>" class="button button-large"><?php _e('Trờ về quản lý giao diện'); ?></a>
				</p>
			<?php
			} else {
			?>
				<h1><?php printf(__('Trình cài đặt nhanh %s.'), wp_get_theme()); ?></h1>
				<p class="lead"><?php printf(__('Cảm ơn bạn đã chọn Cộng Đồng Web, giao diện được phát triển từ Congdongweb Theme. <br/>Mất 3 phút để cấu hình giao diện.'), wp_get_theme()); ?></p>
				<p><?php _e('Bạn có thể bỏ qua và cấu hình giao diện bất cứ lúc nào.'); ?></p>
				<p class="congdongweb-setup-actions step">
					<a href="<?php echo esc_url($this->get_next_step_link()); ?>" class="button-primary button button-large button-next"><?php _e('Bắt đầu'); ?></a>
					<a href="<?php echo esc_url(wp_get_referer() && !strpos(wp_get_referer(), 'update.php') ? wp_get_referer() : admin_url('')); ?>" class="button button-large"><?php _e('Trở về'); ?></a>
				</p>
			<?php
			}
		}

		/**
		 *
		 * Handles save button from welcome page. This is to perform tasks when the setup wizard has already been run. E.g. reset defaults
		 *
		 * @since 1.2.5
		 */
		public function congdongweb_setup_introduction_save()
		{

			check_admin_referer('congdongweb-setup');
			return false;
		}

		private function _get_plugins()
		{
			$instance = call_user_func(array(get_class($GLOBALS['tgmpa']), 'get_instance'));
			$plugins = array(
				'all'      => array(), // Meaning: all plugins which still have open actions.
				'install'  => array(),
				'update'   => array(),
				'activate' => array(),
			);

			foreach ($instance->plugins as $slug => $plugin) {
				if ($instance->is_plugin_active($slug) && false === $instance->does_plugin_have_update($slug)) {
					// No need to display plugins if they are installed, up-to-date and active.
					continue;
				} else {
					$plugins['all'][$slug] = $plugin;

					if (!$instance->is_plugin_installed($slug)) {
						$plugins['install'][$slug] = $plugin;
					} else {
						if (false !== $instance->does_plugin_have_update($slug)) {
							$plugins['update'][$slug] = $plugin;
						}

						if ($instance->can_plugin_activate($slug)) {
							$plugins['activate'][$slug] = $plugin;
						}
					}
				}
			}
			return $plugins;
		}

		/**
		 * Page setup
		 */
		public function congdongweb_setup_default_plugins()
		{

			tgmpa_load_bulk_installer();
			// install plugins with TGM.
			if (!class_exists('TGM_Plugin_Activation') || !isset($GLOBALS['tgmpa'])) {
				die('Failed to find TGM');
			}
			$url = wp_nonce_url(add_query_arg(array('plugins' => 'go')), 'congdongweb-setup');
			$plugins = $this->_get_plugins();

			// copied from TGM

			$method = ''; // Leave blank so WP_Filesystem can populate it as necessary.
			$fields = array_keys($_POST); // Extra fields to pass to WP_Filesystem.

			if (false === ($creds = request_filesystem_credentials(esc_url_raw($url), $method, false, false, $fields))) {
				return true; // Stop the normal page form from displaying, credential request form will be shown.
			}

			// Now we have some credentials, setup WP_Filesystem.
			if (!WP_Filesystem($creds)) {
				// Our credentials were no good, ask the user for them again.
				request_filesystem_credentials(esc_url_raw($url), $method, true, false, $fields);

				return true;
			}

			/* If we arrive here, we have the filesystem */

			?>
			<h1><?php _e('Plugin mặc định', 'congdongweb_setup'); ?></h1>
			<form method="post">

				<?php
				$plugins = $this->_get_plugins();
				if (count($plugins['all'])) {
				?>
					<p class="lead"><?php _e('Các plugin mặc định.', 'congdongweb_setup'); ?></p>
					<ul class="congdongweb-wizard-plugins">
						<?php foreach ($plugins['all'] as $slug => $plugin) {  ?>
							<li data-slug="<?php echo esc_attr($slug); ?>"><?php echo esc_html($plugin['name']); ?>
								<span>
									<?php
									$keys = array();
									if (isset($plugins['install'][$slug])) {
										$keys[] = 'cài';
									}
									if (isset($plugins['update'][$slug])) {
										$keys[] = 'cập nhật';
									}
									if (isset($plugins['activate'][$slug])) {
										$keys[] = 'kích hoạt';
									}
									echo 'Yêu cầu ' . implode(' and ', $keys);
									?>
								</span>
								<div class="spinner"></div>
							</li>
						<?php } ?>
					</ul>
				<?php
				} else {
					echo '<p class="lead">' . __('Tất cả các plugin đã được cài đặt và cập nhật.', 'congdongweb_setup') . '</p>';
				} ?>

				<p class="congdongweb-setup-actions step">
					<a href="<?php echo esc_url($this->get_next_step_link()); ?>" class="button-primary button button-large button-next" data-callback="install_plugins"><?php _e('Tiếp tục', 'congdongweb_setup'); ?></a>
					<a href="<?php echo esc_url($this->get_next_step_link()); ?>" class="button button-large button-next"><?php _e('Bỏ qua', 'congdongweb_setup'); ?></a>
					<?php wp_nonce_field('congdongweb-setup'); ?>
				</p>
			</form>
		<?php
		}


		public function ajax_plugins()
		{
			if (!check_ajax_referer('congdongweb_setup_nonce', 'wpnonce') || empty($_POST['slug'])) {
				wp_send_json_error(array('error' => 1, 'message' => __('No Slug Found', 'congdongweb_setup')));
			}
			$json = array();
			// send back some json we use to hit up TGM
			$plugins = $this->_get_plugins();
			// what are we doing with this plugin?
			foreach ($plugins['activate'] as $slug => $plugin) {
				if ($_POST['slug'] == $slug) {
					$json = array(
						'url' => admin_url($this->tgmpa_url),
						'plugin' => array($slug),
						'tgmpa-page' => $this->tgmpa_menu_slug,
						'plugin_status' => 'all',
						'_wpnonce' => wp_create_nonce('bulk-plugins'),
						'action' => 'tgmpa-bulk-activate',
						'action2' => -1,
						'message' => __('Activating Plugin', 'congdongweb_setup'),
					);
					break;
				}
			}
			foreach ($plugins['update'] as $slug => $plugin) {
				if ($_POST['slug'] == $slug) {
					$json = array(
						'url' => admin_url($this->tgmpa_url),
						'plugin' => array($slug),
						'tgmpa-page' => $this->tgmpa_menu_slug,
						'plugin_status' => 'all',
						'_wpnonce' => wp_create_nonce('bulk-plugins'),
						'action' => 'tgmpa-bulk-update',
						'action2' => -1,
						'message' => __('Updating Plugin', 'congdongweb_setup'),
					);
					break;
				}
			}
			foreach ($plugins['install'] as $slug => $plugin) {
				if ($_POST['slug'] == $slug) {
					$json = array(
						'url' => admin_url($this->tgmpa_url),
						'plugin' => array($slug),
						'tgmpa-page' => $this->tgmpa_menu_slug,
						'plugin_status' => 'all',
						'_wpnonce' => wp_create_nonce('bulk-plugins'),
						'action' => 'tgmpa-bulk-install',
						'action2' => -1,
						'message' => __('Đang cài đặt', 'congdongweb_setup'),
					);
					break;
				}
			}

			if ($json) {
				$json['hash'] = md5(serialize($json)); // used for checking if duplicates happen, move to next plugin
				wp_send_json($json);
			} else {
				wp_send_json(array('done' => 1, 'message' => __('Success', 'congdongweb_setup')));
			}
			exit;
		}

		private function _make_child_theme($new_theme_title)
		{

			$parent_theme_title = 'Congdongweb';
			$parent_theme_template = 'congdongweb';
			$parent_theme_name = get_stylesheet();
			$parent_theme_dir = get_stylesheet_directory();

			// Turn a theme name into a directory name
			$new_theme_name = str_replace('-', '', sanitize_title($new_theme_title));
			$theme_root = get_theme_root();

			// Validate theme name
			$new_theme_path = $theme_root . '/' . $new_theme_name;
			if (file_exists($new_theme_path)) {
				// Don't create child theme.
			} else {
				// Create Child theme
				mkdir($new_theme_path);

				$plugin_folder = get_template_directory() . '/inc/admin/congdongweb_setup/child-theme/';

				// Make style.css
				ob_start();
				require $plugin_folder . 'child-theme-css.php';
				$css = ob_get_clean();
				file_put_contents($new_theme_path . '/style.css', $css);

				// Copy functions.php
				copy($plugin_folder . 'functions.php', $new_theme_path . '/functions.php');

				// Copy screenshot
				copy($plugin_folder . 'screenshot.png', $new_theme_path . '/screenshot.png');

				// Make child theme an allowed theme (network enable theme)
				$allowed_themes = get_site_option('allowedthemes');
				$allowed_themes[$new_theme_name] = true;
				update_site_option('allowedthemes', $allowed_themes);
			}

			// Switch to theme
			if ($parent_theme_template !== $new_theme_name) {
				echo '<p class="lead success">Giao diện con <strong>' . $new_theme_title . '</strong> đã được tạo và kích hoạt! Tại thư mục wp-content/themes/<strong>' . $new_theme_name . '</strong></p>';
				switch_theme($new_theme_name, $new_theme_name);
			}
		}

		private function copy_function_old()
		{

			$slug = congdongweb_theme_key();
			if (is_child_theme())
				$slug = congdongweb_theme_key(basename(get_stylesheet_directory()));
			$theme_root = get_theme_root();



			// Validate theme name
			$new_theme_path = $theme_root . '/' . $slug;
			$old_theme_path = $theme_root . '/flatsome';

			if (file_exists($theme_root . '/flatsome-child')) {
				$old_theme_path = $theme_root . '/flatsome-child';
			}
			if (file_exists($new_theme_path) && file_exists($old_theme_path)) {

				// Copy functions.php
				copy($old_theme_path . '/functions.php', $new_theme_path . '/functions.php');
			}
		}

		/**
		 * Logo & Design
		 */
		public function congdongweb_setup_logo_design()
		{
		?>
			<h1><?php _e('Logo', 'congdongweb_setup'); ?></h1>
			<h3><?php _e('Tải logo', 'congdongweb_setup'); ?></h3>
			<form method="post">

				<table>
					<tr>
						<td>
							<div id="current-logo">
								<?php
								$image_url = $this->get_site_logo();
								if ($image_url) {
									$image = '<img class="site-logo" src="%s" alt="%s" style="width:%s; height:auto" />';
									printf(
										$image,
										$image_url,
										get_bloginfo('name'),
										$this->get_header_logo_width()
									);
								} ?>
							</div>
						</td>
						<td>
							<a href="#" class="button button-upload"><?php _e('Tải logo mới', 'congdongweb_setup'); ?></a>
						</td>
					</tr>
				</table>
				<p>Bạn có thể thay đổi logo trong cài đặt tùy chỉnh.</p>

				<input type="hidden" name="new_logo_id" id="new_logo_id" value="">

				<p class="congdongweb-setup-actions step">
					<input type="submit" class="button-primary button button-large button-next" value="<?php esc_attr_e('Tiếp tục', 'congdongweb_setup'); ?>" name="save_step" />
					<a href="<?php echo esc_url($this->get_next_step_link()); ?>" class="button button-large button-next"><?php _e('Bỏ qua', 'congdongweb_setup'); ?></a>
					<?php wp_nonce_field('congdongweb-setup'); ?>
				</p>
			</form>
		<?php
		}

		/**
		 * Save logo & design options
		 */
		public function congdongweb_setup_logo_design_save()
		{
			check_admin_referer('congdongweb-setup');

			$new_logo_id = (int) $_POST['new_logo_id'];

			if ($new_logo_id) {
				set_theme_mod('site_logo', $new_logo_id);
			}

			wp_redirect(esc_url_raw($this->get_next_step_link()));
			exit;
		}


		public function congdongweb_setup_customize()
		{
		?>

			<h1>Tạo giao diện con</h1>

			<p>
				Cộng đồng web sẽ tạo 1 giao diện con. Bạn có thể thêm code chỉnh sửa ở thư mục này thay vì bạn chỉnh trực tiếp trên thư mục gốc. Tránh trường hợp mất code sau khi cập nhật giao diện chính. Hướng dẫn <a href="https://codex.wordpress.org/Child_Themes" target="_blank">tại đây</a>
			</p>

			<?php if (!isset($_REQUEST['theme_name'])) { ?>
				<p class="lead">Bạn có thể bỏ qua bước này.</p>
			<?php } ?>

			<?php
			// Create Child Theme
			if (isset($_REQUEST['theme_name']) && current_user_can('manage_options')) {
				$this->_make_child_theme(esc_html($_REQUEST['theme_name']));
			}
			$theme = 'Cộng đồng web Child';
			?>

			<?php if (!isset($_REQUEST['theme_name'])) { ?>

				<form action="<?php $_PHP_SELF ?>" method="POST">
					<div class="child-theme-input" style="margin-bottom: 20px;">
						<label style="font-weight: bold;margin-bottom: 5px; display: block;">Nhập tên giao diện con</label>
						<input type="text" style="padding:10px; width: 100%;" name="theme_name" value="<?php echo $theme; ?>" />
					</div>
					<p class="congdongweb-setup-actions step">
						<button type="submit" id=type="submit" class="button button-primary button-next button-next">
							<?php _e('Tạo giao diện con', 'congdongweb_setup'); ?>
						</button>
						<a href="<?php echo esc_url($this->get_next_step_link()); ?>" class="button button-large button-next"><?php _e('Bỏ qua', 'congdongweb_setup'); ?></a>

					</p>
				</form>
			<?php } else { ?>
				<p class="congdongweb-setup-actions step">
					<a href="<?php echo esc_url($this->get_next_step_link()); ?>" class="button button-primary button-large button-next"><?php _e('Tiếp tục', 'congdongweb_setup'); ?></a>
				</p>
			<?php } ?>
		<?php
		}
		public function congdongweb_setup_help_support()
		{
		?>
			<h1>Liên hệ và Hỗ trợ</h1>
			<p class="lead">Hãy gửi email ngay cho chúng tôi khi các bạn cần hỗ trợ, nếu bạn cần gấp có thể gọi ngay hotline cho chúng tôi, Cộng Đồng Web sẽ gửi email phản hồi cho các bạn nhanh nhất có thể. <a href="https://www.congdongweb.com/lien-he/">Liên hệ</a></p>

			<p class="success">Phương thức <strong>liên hệ</strong>:</p>
			<?php
			$this->register();
			$this->register_option_default();
			$this->register_permalink();
			$this->copy_function_old();
			?>
			<ul>
				<li>168/32 Nguyễn Gia Trí, Phường 25, Quận Bình Thạnh, HCM</li>
				<li>Điện thoại: <a href="tel:035 381 4306"> 035 381 4306</a> - <a href="tel: 0386270225"> 0386.270.225</a></li>
				<li>Email liên hệ: <a href="mailto:hotro@congdongweb.com">hotro@congdongweb.com</a></li>
			</ul>

			<p class="error">Hỗ trợ <strong>Online</strong>:</p>
			<ul class="messangers-list cdw-downtoup rounded-items">
				<li><a href="https://www.congdongweb.com/admin/?module=client&amp;action=ticket" class="messanger msg-item-comment-lines-light" id="msg-item-2" rel="nofollow noopener" title="Chat 24/7" target="_blank">

						<span>Chat 24/7</span>

					</a></li>
				<li><a class="messanger msg-item-phone" id="msg-item-5" rel="nofollow noopener" href="tel:0386270225" title="Hotline" target="_blank">

						<span>Hotline</span>

					</a></li>
				<li><a class="messanger msg-item-envelope" id="msg-item-6" rel="nofollow noopener" href="mailto:hotro@congdongweb.com" title="Gửi phiếu hỗ trợ" target="_blank">

						<span>Gửi hỗ trợ Email</span>

					</a></li>
				<li><a class="messanger msg-item-" id="msg-item-1" rel="nofollow noopener" href="https://zalo.me/0386270225" title="Zalo" target="_blank">

						<span>Zalo</span>

					</a></li>
				<li><a class="messanger msg-item-" id="msg-item-1" rel="nofollow noopener" href="https://zalo.me/0353814306" title="Zalo" target="_blank">

						<span>Zalo</span>

					</a></li>
				<li><a class="messanger msg-item-facebook" id="msg-item-3" rel="nofollow noopener" href="https://www.facebook.com/congdongweb" title="Facebook" target="_blank">

						<span>Facebook</span>

					</a></li>
				<li><a class="messanger msg-item-fa" id="msg-item-4" rel="nofollow noopener" href="https://www.youtube.com/@congdongweb" title="Youtube" target="_blank">

						<span>Youtube</span>

					</a></li>
			</ul>
			<p class="congdongweb-setup-actions step">
				<a href="<?php echo esc_url($this->get_next_step_link()); ?>" class="button button-primary button-large button-next"><?php _e('Đồng ý và tiếp tục', 'congdongweb_setup'); ?></a>
				<?php wp_nonce_field('congdongweb-setup'); ?>
			</p>
		<?php
		}

		/**
		 * Final step
		 */
		public function congdongweb_setup_ready()
		{

			update_option('congdongweb_setup_complete', time());
		?>

			<h1><?php _e('Hoàn tất quá trình cài đặt!', 'congdongweb_setup'); ?></h1>

			<p class="lead success">Chúc mừng! Chủ đề đã được kích hoạt và trang web của bạn đã sẵn sàng.</p>

			<div class="congdongweb-setup-next-steps">
				<div class="congdongweb-setup-next-steps-first">
					<h2><?php _e('Cộng đồng', 'congdongweb_setup'); ?></h2>
					<ul>
						<li class="setup-product"><a class="button button-primary button-large" href="https://www.facebook.com/congdongwebsite/" target="_blank"><?php _e('Fanpage', 'congdongweb_setup'); ?></a></li>
						<li class="setup-product"><a class="button button-large" href="<?php echo esc_url(home_url()) . '/wp-admin'; ?>"><?php _e('Trang quản trị!', 'congdongweb_setup'); ?></a></li>
					</ul>
				</div>
				<div class="congdongweb-setup-next-steps-last">
					<h2><?php _e('Cộng Đồng Web', 'congdongweb_setup'); ?></h2>
					<ul>
						<li class="documentation"><a href="https://www.congdongweb.com/kho-giao-dien/"><?php _e('Kho giao diện', 'congdongweb_setup'); ?></a></li>
						<li class="documentation"><a href="https://www.congdongweb.com/dang-ky-ten-mien/"><?php _e('Tên miền', 'congdongweb_setup'); ?></a></li>
						<li class="documentation"><a href="https://www.congdongweb.com/vps-server/"><?php _e('VPS & Hosting', 'congdongweb_setup'); ?></a></li>
						<li class="rating"><a href="https://www.congdongweb.com/lien-he/"><?php _e('Liên hệ', 'congdongweb_setup'); ?></a></li>
					</ul>
				</div>
			</div>
<?php
		}
	}
} // if !class_exists

/**
 * Loads the main instance of CongDongWeb_Theme_Setup_Wizard to have
 * ability extend class functionality
 *
 * @since 1.1.1
 * @return object CongDongWeb_Theme_Setup_Wizard
 */

add_action('after_setup_theme', 'congdongweb_theme_setup_wizard', 10);

if (!function_exists('congdongweb_theme_setup_wizard')) :
	function congdongweb_theme_setup_wizard()
	{
		CongDongWeb_Theme_Setup_Wizard::get_instance();
	}
endif;
