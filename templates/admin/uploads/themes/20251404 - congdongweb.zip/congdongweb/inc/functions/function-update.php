<?php

/**
 * Congdongweb Update Functions
 *
 * @author  UX Themes
 * @package Congdongweb/Functions
 */

/**
 * Inject update data for Congdongweb to `_site_transient_update_themes`.
 * The `package` property is a temporary URL which will be replaced with
 * an actual URL to a zip file in the `upgrader_package_options` hook when
 * WordPress runs the upgrader.
 *
 * @param array $transient The pre-saved value of the `update_themes` site transient.
 * @return array
 */
function congdongweb_get_update_info($transient)
{
	static $latest_version;

	if (!isset($transient->checked)) {
		return $transient;
	}

	$theme    = wp_get_theme(get_template());
	$template = $theme->get_template();
	$version  = $theme->get('Version');

	$update_details = array(
		'theme'       => $template,
		'new_version' => $version,
		'url'         => add_query_arg(
			array(
				'version' => $version,
			),
			esc_url(admin_url('admin.php?page=congdongweb-version-info'))
		),
		'package'     => add_query_arg(
			array(
				'congdongweb_version'  => $version,
				'congdongweb_download' => true,
			),
			esc_url(admin_url('admin.php?page=congdongweb-panel'))
		),
	);
	if (empty($latest_version)) {
		$cache = get_option('congdongweb_update_cache');
		$now   = time();

		if (
			!empty($cache['version']) &&
			!empty($cache['last_checked']) &&
			$now - ((int) $cache['last_checked']) < 300
		) {
			$latest_version = $cache['version'];
		} else {
			$result         =  get_latest_version();
			$latest_version = is_string($result) ? $result : $version;

			update_option(
				'congdongweb_update_cache',
				array(
					'last_checked' => $now,
					'version'      => $latest_version,
				)
			);
		}
	}

	if (version_compare($version, $latest_version, '<')) {

		$update_details['new_version'] = $latest_version;
		$update_details['url']         = add_query_arg('version', $latest_version, $update_details['url']);
		$update_details['package']     = add_query_arg('congdongweb_version', $latest_version, $update_details['package']);

		$transient->response[$template] = $update_details;
	} else {

		congdongweb_inc_admin()->registration->set_errors(array());
		$transient->no_update[$template] = $update_details;
	}

	return $transient;
}
add_filter('pre_set_site_transient_update_themes', 'congdongweb_get_update_info', 1, 99999);
add_filter('pre_set_transient_update_themes', 'congdongweb_get_update_info', 1, 99999);

function get_code()
{
	return get_option(congdongweb_theme_key() . '_purchase_code', false);
}
function get_latest_version()
{
	$code = get_code();

	if (empty($code)) {
		return new WP_Error('missing-purchase-code', __('Bạn chưa có code truy cập theme này.', 'congdongweb'));
	}

	$theme    = wp_get_theme(get_template());
	$template = $theme->get_template();

	$api = new CDW_API();
	$result = $api->send_request("/wp-admin/admin-ajax.php", 'latest-version', ['body' => ['type' => 'theme', 'name' => $template, 'action' => 'manage-version-latest', 'code' => $code]]);

	if (is_wp_error($result)) {
		$statuses = array(400, 403, 404, 409, 410, 423);
		if (in_array((int) $result->get_error_code(), $statuses, true)) {
			congdongweb_inc_admin()->registration->set_errors(array($result->get_error_message()));
		}
		return $result;
	} else {
		congdongweb_inc_admin()->registration->set_errors(array());
	}

	if (empty($result['version'])) {
		return new WP_Error('missing-version', __('No version received.', 'congdongweb'));
	}

	if (!is_string($result['version'])) {
		return new WP_Error('invalid-version', __('Invalid version received.', 'congdongweb'));
	}
	congdongweb_inc_admin()->registration->set_errors(array($result['msg']));

	return $result['version'];
}
/**
 * Get a fresh package URL before running the WordPress upgrader.
 *
 * @param array $options Options used by the upgrader.
 * @return array
 */

function get_download_url($version)
{
	$code = get_code();

	if (empty($code)) {
		return new WP_Error('missing-purchase-code', __('Bạn chưa có code truy cập theme này.', 'congdongweb'));
	}

	$theme    = wp_get_theme(get_template());
	$template = $theme->get_template();
	$api = new CDW_API();
	$result = $api->send_request("/wp-admin/admin-ajax.php", 'download-url', ['body' => ['type' => 'theme', 'name' => $template, 'action' => 'manage-version-download', 'code' => $code, 'version' => $version]]);

	if (is_wp_error($result)) {
		return $result;
	}

	if (empty($result['url'])) {
		return new WP_Error('missing-url', __('No URL received.', 'congdongweb'));
	}

	if (!is_string($result['url'])) {
		return new WP_Error('invalid-url', __('Invalid URL received.', 'congdongweb'));
	}

	return $result['url'];
}

function congdongweb_upgrader_package_options($options)
{
	$package = $options['package'];
	if (false !== strrpos($package, 'congdongweb_download')) {
		parse_str(wp_parse_url($package, PHP_URL_QUERY), $vars);

		if (isset($vars['congdongweb_version'])) {
			$version = $vars['congdongweb_version'];
			$package = get_download_url($version);

			if (is_wp_error($package)) {
				return $options;
			}

			$options['package'] = $package;
		}
	}

	return $options;
}
add_filter('upgrader_package_options', 'congdongweb_upgrader_package_options', 9);

/**
 * Disables update check for Congdongweb in the WordPress themes repo.
 *
 * @param array  $request An array of HTTP request arguments.
 * @param string $url The request URL.
 * @return array
 */
function congdongweb_update_check_request_args($request, $url)
{
	if (false !== strpos($url, '//api.wordpress.org/themes/update-check/1.1/')) {
		$data     = json_decode($request['body']['themes']);
		$template = get_template();
		unset($data->themes->$template);
		// echo '<pre>';
		// var_dump($data);
		// echo '</pre>';
		$request['body']['themes'] = wp_json_encode($data);
	}
	return $request;
}
add_filter('http_request_args', 'congdongweb_update_check_request_args', 5, 2);
