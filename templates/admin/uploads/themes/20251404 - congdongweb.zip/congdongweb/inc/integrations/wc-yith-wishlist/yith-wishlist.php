<?php
/**
 * YITH wishlist integration
 *
 * @author      UX Themes
 * @package     Congdongweb/Integrations
 */

if ( ! function_exists( 'congdongweb_wishlist_integrations_scripts' ) ) {
	/**
	 * Enqueues wishlist integrations scripts
	 */
	function congdongweb_wishlist_integrations_scripts() {
		global $integrations_uri;

		wp_dequeue_style( 'yith-wcwl-main' );
		wp_deregister_style( 'yith-wcwl-main' );
		wp_dequeue_style( 'yith-wcwl-font-awesome' );
		wp_deregister_style( 'yith-wcwl-font-awesome' );

		// TODO 4.0 Move and apply on AJAX search plugin.
		wp_dequeue_style( 'yith_wcas_frontend' );
		wp_deregister_style( 'yith_wcas_frontend' );

		wp_enqueue_script( 'congdongweb-woocommerce-wishlist',  $integrations_uri . '/wc-yith-wishlist/wishlist.js', array( 'jquery', 'congdongweb-js' ), '3.10.2', true );
		wp_enqueue_style( 'congdongweb-woocommerce-wishlist', $integrations_uri . '/wc-yith-wishlist/wishlist.css', 'congdongweb-woocommerce-style', '3.10.2' );
	}
}
add_action( 'wp_enqueue_scripts', 'congdongweb_wishlist_integrations_scripts' );

if ( ! function_exists( 'congdongweb_wishlist_account_item' ) ) {
	/**
	 * Add wishlist button to my account dropdown
	 */
	function congdongweb_wishlist_account_item() {
		$page_id = get_option( 'yith_wcwl_wishlist_page_id' );
		if ( ! $page_id ) {
			return;
		}

		$wishlist_page = yith_wcwl_object_id( $page_id );
		?>
		<li class="wishlist-account-element <?php if ( is_page( $wishlist_page ) ) echo 'active'; ?>">
			<a href="<?php echo YITH_WCWL()->get_wishlist_url(); ?>"><?php echo get_the_title( $wishlist_page ); ?></a>
		</li>
		<?php
	}
}
add_action( 'congdongweb_account_links', 'congdongweb_wishlist_account_item' );


if ( ! function_exists( 'congdongweb_product_wishlist_button' ) ) {
	/**
	 * Add wishlist Button to Product Image
	 */
	function congdongweb_product_wishlist_button() {
		$icon = get_theme_mod( 'wishlist_icon', 'heart' );
		if ( ! $icon ) $icon = 'heart';
		?>
		<div class="wishlist-icon">
			<button class="wishlist-button button is-outline circle icon" aria-label="<?php echo __( 'Wishlist', 'congdongweb' ); ?>">
				<?php echo get_congdongweb_icon( 'icon-' . $icon ); ?>
			</button>
			<div class="wishlist-popup dark">
				<?php echo do_shortcode( '[yith_wcwl_add_to_wishlist]' ); ?>
			</div>
		</div>
		<?php
	}
}
add_action( 'congdongweb_product_image_tools_top', 'congdongweb_product_wishlist_button', 2 );
add_action( 'congdongweb_product_box_tools_top', 'congdongweb_product_wishlist_button', 2 );

if ( ! function_exists( 'congdongweb_header_wishlist' ) ) {
	/**
	 * Header Wishlist element
	 *
	 * @param $elements
	 * @return mixed
	 */
	function congdongweb_header_wishlist( $elements ) {
		$elements['wishlist'] = __( 'Wishlist', 'congdongweb' );

		return $elements;
	}
}
add_filter( 'congdongweb_header_element', 'congdongweb_header_wishlist' );

if ( ! function_exists( 'congdongweb_update_wishlist_count' ) ) {
	/**
	 * Update Wishlist Count
	 */
	function congdongweb_update_wishlist_count() {
		wp_send_json( YITH_WCWL()->count_products() );
	}
}
add_action( 'wp_ajax_congdongweb_update_wishlist_count', 'congdongweb_update_wishlist_count' );
add_action( 'wp_ajax_nopriv_congdongweb_update_wishlist_count', 'congdongweb_update_wishlist_count' );
