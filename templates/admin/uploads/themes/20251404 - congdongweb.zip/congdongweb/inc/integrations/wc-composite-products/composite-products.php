<?php
/**
 * Composite Products integration
 *
 * @author      UX Themes
 * @package     Congdongweb/Integrations
 * @see         https://woocommerce.com/products/composite-products/
 */

/**
 *  Composite products integration script.
 */
function congdongweb_wc_composite_products_integration() {
	global $integrations_uri;
	wp_enqueue_script( 'congdongweb-composite-products', $integrations_uri . '/wc-composite-products/composite-products.js', array( 'jquery', 'congdongweb-js' ), 1.2, true );
}

add_action( 'wp_enqueue_scripts', 'congdongweb_wc_composite_products_integration' );

/**
 * Disabled sticky add to cart on composite products type.
 *
 * @param bool       $enabled Default enabled.
 * @param WC_Product $product The product object.
 *
 * @return bool
 */
function congdongweb_wc_composite_products_disable_sticky_add_to_cart( $enabled, $product ) {
	if ( $product->get_type() == 'composite' ) {
		return false;
	}

	return $enabled;
}

add_filter( 'congdongweb_sticky_add_to_cart_enabled', 'congdongweb_wc_composite_products_disable_sticky_add_to_cart', 10, 2 );
