<?php
/**
 * Congdongweb Cart refresh extension
 *
 * @author     UX Themes
 * @category   Extension
 * @package    Congdongweb/Extensions
 * @since      3.6.0
 */

/**
 * To be enqueued refresh script.
 */
function congdongweb_cart_refresh_script() {
	global $extensions_uri;
	$theme   = wp_get_theme( get_template() );
	$version = $theme->get( 'Version' );
	wp_enqueue_script( 'congdongweb-cart-refresh', $extensions_uri . '/congdongweb-cart-refresh/congdongweb-cart-refresh.js', array( 'jquery', 'congdongweb-js' ), $version, true );
}

/**
 * Add extension script if on cart page.
 */
function congdongweb_add_cart_refresh_script() {
	if ( is_cart() ) {
		add_action( 'wp_enqueue_scripts', 'congdongweb_cart_refresh_script' );
	}
}

add_action( 'wp', 'congdongweb_add_cart_refresh_script' );

