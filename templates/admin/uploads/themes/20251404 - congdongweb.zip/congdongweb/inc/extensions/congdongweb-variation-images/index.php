<?php // @codingStandardsIgnoreLine


namespace Congdongweb\Extensions;

defined( 'ABSPATH' ) || exit;


global $extensions_url;
require $extensions_url . '/congdongweb-variation-images/includes/class-variation-images.php';

variation_images();
