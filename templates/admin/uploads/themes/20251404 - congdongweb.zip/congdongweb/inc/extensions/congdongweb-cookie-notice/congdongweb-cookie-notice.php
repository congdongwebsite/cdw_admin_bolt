<?php
/**
 * Congdongweb Cookie notice extension
 *
 * @author     UX Themes
 * @category   Extension
 * @package    Congdongweb/Extensions
 * @since      3.12.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enqueue extensions scripts.
 */
function congdongweb_cookie_notice_scripts() {
	global $extensions_uri;

	wp_enqueue_script( 'congdongweb-cookie-notice', $extensions_uri . '/congdongweb-cookie-notice/congdongweb-cookie-notice.js', array( 'jquery', 'congdongweb-js' ), '3.12.0', true );
}

add_action( 'wp_enqueue_scripts', 'congdongweb_cookie_notice_scripts' );

/**
 * Html template for cookie notice.
 */
function congdongweb_cookie_notice_template() {
	if ( ! get_theme_mod( 'cookie_notice' ) ) {
		return;
	}

	$classes = array( 'congdongweb-cookies' );
	if ( get_theme_mod( 'cookie_notice_text_color' ) === 'dark' ) {
		$classes[] = 'dark';
	}
	$text = get_theme_mod( 'cookie_notice_text' );
	$id   = get_theme_mod( 'privacy_policy_page' );
	$page = $id ? get_post( $id ) : false;
	$text = $text ? $text : __( 'This site uses cookies to offer you a better browsing experience. By browsing this website, you agree to our use of cookies.', 'congdongweb' );
	?>
	<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
		<div class="congdongweb-cookies__inner">
			<div class="congdongweb-cookies__text">
				<?php echo do_shortcode( $text ); ?>
			</div>
			<div class="congdongweb-cookies__buttons">
				<?php
				if ( $page ) {
					echo congdongweb_apply_shortcode( 'button', array(
						'text'  => _x( 'More info', 'cookie notice', 'congdongweb' ),
						'style' => get_theme_mod( 'cookie_notice_button_style', '' ),
						'link'  => get_permalink( $page->ID ),
						'color' => 'secondary',
						'class' => 'congdongweb-cookies__more-btn',
					) );
				}
				?>
				<?php
				echo congdongweb_apply_shortcode( 'button', array(
					'text'  => _x( 'Accept', 'cookie notice', 'congdongweb' ),
					'style' => get_theme_mod( 'cookie_notice_button_style', '' ),
					'link'  => '#',
					'color' => 'primary',
					'class' => 'congdongweb-cookies__accept-btn',
				) );
				?>
			</div>
		</div>
	</div>
	<?php
}

add_action( 'wp_footer', 'congdongweb_cookie_notice_template' );
