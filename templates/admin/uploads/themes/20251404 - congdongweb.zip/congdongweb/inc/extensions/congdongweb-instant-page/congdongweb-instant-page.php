<?php
/**
 * Congdongweb Instant Page extension
 *
 * @author     UX Themes
 * @category   Extension
 * @package    Congdongweb/Extensions
 * @since      3.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

add_action( 'wp_enqueue_scripts', 'congdongweb_instant_page' );

if ( ! function_exists( 'congdongweb_instant_page' ) ) :

function congdongweb_instant_page() {
  global $extensions_uri;

  wp_enqueue_script(
    'congdongweb-instant-page',
    $extensions_uri . '/congdongweb-instant-page/congdongweb-instant-page.js',
    array(),
    '1.2.1',
    true
  );
}

endif;
