/* global congdongwebVars, cookie */
jQuery(document).ready(function () {
  'use strict'
  var $notice = jQuery('.congdongweb-cookies')
  var cookieId = 'congdongweb_cookie_notice'
  var cookieValue = congdongwebVars.options.cookie_notice_version

  if (cookie(cookieId) !== cookieValue) {
    setTimeout(function () {
      $notice.addClass('congdongweb-cookies--active')

      $notice.on('click', '.congdongweb-cookies__accept-btn', function (e) {
        e.preventDefault()
        $notice.removeClass('congdongweb-cookies--active').addClass('congdongweb-cookies--inactive')
        // set cookie
        cookie(cookieId, cookieValue, 365)
      })
    }, 2500)
  }
})
