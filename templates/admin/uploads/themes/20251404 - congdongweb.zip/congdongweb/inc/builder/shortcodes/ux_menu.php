<?php
/**
 * Registers the Menu element in UX Builder.
 *
 * @package congdongweb
 */

add_ux_builder_shortcode( 'ux_menu', array(
	'type'      => 'container',
	'name'      => __( 'Menu', 'congdongweb' ),
	'category'  => __( 'Content', 'congdongweb' ),
	'allow'     => array( 'ux_menu_link', 'ux_menu_title' ),
	'thumbnail' => congdongweb_ux_builder_thumbnail( 'ux_menu' ),
	'template'  => congdongweb_ux_builder_template( 'ux_menu.html' ),
	'wrap'      => false,
	'nested'    => false,
	'presets'   => array(
		array(
			'name'    => __( 'Default', 'congdongweb' ),
			'content' => '
				[ux_menu divider="solid"]
					[ux_menu_link text="Menu link 1"]
					[ux_menu_link text="Menu link 2"]
					[ux_menu_link text="Menu link 3"]
					[ux_menu_link text="Menu link 4"]
				[/ux_menu]
			',
		),
	),
	'options'   => array(
		'divider'          => array(
			'type'       => 'radio-buttons',
			'heading'    => __( 'Divider', 'congdongweb' ),
			'responsive' => true,
			'default'    => '',
			'options'    => array(
				''      => array( 'title' => __( 'None', 'congdongweb' ) ),
				'solid' => array( 'title' => __( 'Solid', 'congdongweb' ) ),
			),
		),
		'advanced_options' => require __DIR__ . '/commons/advanced.php',
	),
) );
