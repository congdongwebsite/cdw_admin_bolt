<?php

ux_builder_add_template( 'congdongweb_blank', array(
  'name' => __( 'Blank', 'congdongweb' ),
  'thumbnail' => congdongweb_ux_builder_thumbnail( 'play' ),
  'content' => '',
) );
