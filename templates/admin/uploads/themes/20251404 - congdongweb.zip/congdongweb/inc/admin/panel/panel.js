jQuery(function ($) {});
