<?php
/**
 * Search form element.
 *
 * @package          Congdongweb\Templates
 * @congdongweb-version 3.16.0
 */

?>
<li class="header-search-form search-form html relative has-icon">
	<div class="header-search-form-wrapper">
		<?php echo do_shortcode('[search style="'.congdongweb_option('header_search_form_style').'"]'); ?>
	</div>
</li>
