<?php
/**
 * Cart replace element.
 *
 * @package          Congdongweb\Templates
 * @congdongweb-version 3.16.0
 */

if(congdongweb_option('catalog_mode_header')) echo '<li class="html cart-replace">'.do_shortcode(congdongweb_option('catalog_mode_header')).'</li>';
