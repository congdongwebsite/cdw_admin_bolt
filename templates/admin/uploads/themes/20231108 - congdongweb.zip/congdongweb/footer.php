<?php
/**
 * The template for displaying the footer.
 *
 * @package          Congdongweb\Templates
 * @congdongweb-version 3.16.0
 */

global $congdongweb_opt;
?>

</main>

<footer id="footer" class="footer-wrapper">

	<?php do_action('congdongweb_footer'); ?>

</footer>

</div>

<?php wp_footer(); ?>

</body>
</html>
