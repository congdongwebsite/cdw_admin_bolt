<?php
/**
 * Status tab.
 *
 * @package Congdongweb\Admin
 */

?>
<div id="tab-status">
	<?php Congdongweb\Admin\status()->render_panel(); ?>
</div>
