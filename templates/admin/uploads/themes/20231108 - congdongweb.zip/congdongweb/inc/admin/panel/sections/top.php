<?php

/**
 * Flatome Panel
 */
?>
<?php add_thickbox(); ?>
<?php $congdongweb_ver = wp_get_theme(get_template());  ?>
<h1>
    <?php echo '<strong>Welcome to ' . wp_get_theme() . '</strong>'; ?>
</h1>
<div class="about-text">
    <?php _e('Cảm ơn bạn đã tin tưởng sử dụng dịch vụ của chúng tôi.', 'congdongweb-admin'); ?>
    <br><br>
    <a href="<?php echo admin_url() . 'admin.php?page=congdongweb-setup'; ?>" class="button button-primary button-large"><?php _e('Cài đặt nhanh', 'congdongweb-admin'); ?></a>
</div>

<div class="wp-badge fl-badge">Phiên bản <?php echo $congdongweb_ver['Version']; ?></div>

<h2 class="nav-tab-wrapper">
    <?php $url = admin_url() . 'admin.php?page=congdongweb-panel' ?>
    <a href="<?php echo $url . '-support'; ?>" class="nav-tab <?php if ($_GET['page'] == 'congdongweb-panel-support' || $_GET['page'] == 'congdongweb-panel') echo 'nav-tab-active'; ?>"><?php _e('Hỗ trợ', 'congdongweb-admin'); ?></a>
    <a href="<?php echo $url . '-options'; ?>" class="nav-tab <?php if ($_GET['page'] == 'congdongweb-panel-options') echo 'nav-tab-active'; ?>"><?php _e('Tùy chọn', 'congdongweb-admin'); ?></a>
    <a href="<?php echo $url . '-status'; ?>" class="nav-tab <?php if ($_GET['page'] == 'congdongweb-panel-status') echo 'nav-tab-active'; ?>"><?php _e('Tình trạng', 'congdongweb-admin'); ?></a>
    <a href="<?php echo $url . '-changelog'; ?>" class="nav-tab <?php if ($_GET['page'] == 'congdongweb-panel-changelog') echo 'nav-tab-active'; ?>"><?php _e('Log', 'congdongweb-admin'); ?></a>
</h2>