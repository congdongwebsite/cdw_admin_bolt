<?php

/*************
 * Header Main
 *************/

Congdongweb_Option::add_section( 'header-layout', array(
	'title'       => __( 'Elements', 'congdongweb-admin' ),
	'panel'       => 'header',
	//'description' => __( 'This is the section description', 'congdongweb-admin' ),
) );

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'text',
	'settings'     => 'congdongweb_version',
	'label'       => __( 'Congdongweb Version', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'default'     => '',
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'topbar_elements_left',
	'label'       => __( '← Left Elements', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'multiple'    => 5,
	'default'     => congdongweb_topbar_elements_left(),
	'transport' => $transport,
	'choices'     => $nav_elements
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'topbar_elements_center',
	'label'       => __( 'Center Elements', 'congdongweb-admin' ),
	//'description' => __( 'This is the control description', 'congdongweb-admin' ),
	//'help'        => __( 'This is some extra help. You can use this to add some additional instructions for users. The main description should go in the "description" of the field, this is only to be used for help tips.', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'multiple'    => 5,
	'default'     => array(),
	'transport' => $transport,
	'choices'     => $nav_elements
));


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'topbar_elements_right',
	'label'       => __( 'Right Elements →', 'congdongweb-admin' ),
	//'description' => __( 'This is the control description', 'congdongweb-admin' ),
	//'help'        => __( 'This is some extra help. You can use this to add some additional instructions for users. The main description should go in the "description" of the field, this is only to be used for help tips.', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'multiple'    => 5,
	'transport' => $transport,
	'default'     => congdongweb_topbar_elements_right(),
	'choices'     => $nav_elements
));


Congdongweb_Option::add_field( '', array(
    'type'        => 'custom',
    'settings' => 'custom_title_header_layout_main',
    'label'       => __( '', 'congdongweb-admin' ),
	'section'     => 'header-layout',
    'default'     => '<div class="options-title-divider">Main Header</div>',
) );

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'header_elements_left',
	'label'       => __( 'Left Elements', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'transport' => 'postMessage',
	'multiple' => 5,
	'default'     => congdongweb_header_elements_left(),
	'choices'     => $nav_elements
));


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'header_elements_right',
	'label'       => __( 'Right Elements', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'transport' => 'postMessage',
	'multiple' => 5,
	'default'     => congdongweb_header_elements_right(),
	'choices'     => $nav_elements
));


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'header_elements_bottom_left',
	'label'       => __( 'Left Elements', 'congdongweb-admin' ),
	//'description' => __( 'This is the control description', 'congdongweb-admin' ),
	//'help'        => __( 'This is some extra help. You can use this to add some additional instructions for users. The main description should go in the "description" of the field, this is only to be used for help tips.', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'multiple'    => 5,
	'default'     => congdongweb_header_elements_bottom_left(),
	'transport' => $transport,
	'choices'     => $nav_elements
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'header_elements_bottom_center',
	'label'       => __( 'Left Elements', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'multiple'    => 5,
	'default'     => congdongweb_header_elements_bottom_center(),
	'transport' => $transport,
	'choices'     => $nav_elements
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'header_elements_bottom_right',
	'label'       => __( 'Right Elements', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'multiple'    => 5,
	'default'     => congdongweb_header_elements_bottom_right(),
	'transport' => $transport,
	'choices'     => $nav_elements
));



Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'header_mobile_elements_top',
	'label'       => __( 'Mobile Top', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'multiple'    => 5,
	'default'     => congdongweb_header_mobile_elements_top(),
	'transport' => $transport,
	'choices'     => $nav_elements
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'header_mobile_elements_left',
	'label'       => __( 'Left Elements', 'congdongweb-admin' ),
	//'description' => __( 'This is the control description', 'congdongweb-admin' ),
	//'help'        => __( 'This is some extra help. You can use this to add some additional instructions for users. The main description should go in the "description" of the field, this is only to be used for help tips.', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'multiple'    => 5,
	'default'     => congdongweb_header_mobile_elements_left(),
	'transport' => $transport,
	'choices'     => $nav_elements
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'header_mobile_elements_right',
	'label'       => __( 'Left Elements', 'congdongweb-admin' ),
	//'description' => __( 'This is the control description', 'congdongweb-admin' ),
	//'help'        => __( 'This is some extra help. You can use this to add some additional instructions for users. The main description should go in the "description" of the field, this is only to be used for help tips.', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'multiple'    => 5,
	'default'     => congdongweb_header_mobile_elements_right(),
	'transport' => $transport,
	'choices'     => $nav_elements
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'select',
	'settings'     => 'header_mobile_elements_bottom',
	'label'       => __( 'Left Elements', 'congdongweb-admin' ),
	//'description' => __( 'This is the control description', 'congdongweb-admin' ),
	//'help'        => __( 'This is some extra help. You can use this to add some additional instructions for users. The main description should go in the "description" of the field, this is only to be used for help tips.', 'congdongweb-admin' ),
	'section'     => 'header-layout',
	'multiple'    => 5,
	'default'     => array(),
	'transport' => $transport,
	'choices'     => $nav_elements
));