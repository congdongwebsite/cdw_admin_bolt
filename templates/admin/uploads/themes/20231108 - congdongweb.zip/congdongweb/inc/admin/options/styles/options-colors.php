<?php
/**
 * Style & Colors
 */

Congdongweb_Option::add_section( 'colors', array(
	'title' => __( 'Colors', 'congdongweb-admin' ),
	'panel' => 'style',
) );

Congdongweb_Option::add_field( '', array(
	'type'     => 'custom',
	'settings' => 'custom_title_colors_main',
	'label'    => __( '', 'congdongweb-admin' ),
	'section'  => 'colors',
	'default'  => '<div class="options-title-divider">Main Colors</div>',
) );

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'color',
	'settings'    => 'color_primary',
	'label'       => __( 'Primary Color', 'congdongweb-admin' ),
	'description' => __( 'Change primary color.', 'congdongweb-admin' ),
	'section'     => 'colors',
	'default'     => Congdongweb_Default::COLOR_PRIMARY,
	'transport'   => $transport,
) );

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'color',
	'settings'    => 'color_secondary',
	'transport'   => $transport,
	'label'       => __( 'Secondary Color', 'congdongweb-admin' ),
	'description' => __( 'Change secondary color.', 'congdongweb-admin' ),
	'default'     => Congdongweb_Default::COLOR_SECONDARY,
	'section'     => 'colors',
) );

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'color',
	'settings'    => 'color_success',
	'transport'   => $transport,
	'label'       => __( 'Success Color', 'congdongweb-admin' ),
	'description' => __( 'Change the success color. Used for global success messages.', 'congdongweb-admin' ),
	'section'     => 'colors',
	'default'     => Congdongweb_Default::COLOR_SUCCESS,
) );

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'color',
	'settings'    => 'color_alert',
	'transport'   => $transport,
	'label'       => __( 'Alert Color', 'congdongweb-admin' ),
	'description' => __( 'Change the alert color. Used for global error messages etc.', 'congdongweb-admin' ),
	'section'     => 'colors',
	'default'     => Congdongweb_Default::COLOR_ALERT,
) );

Congdongweb_Option::add_field( '', array(
	'type'     => 'custom',
	'settings' => 'custom_title_color_type',
	'label'    => __( '', 'congdongweb-admin' ),
	'section'  => 'colors',
	'default'  => '<div class="options-title-divider">Type</div>',
) );

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'color',
	'settings'    => 'color_texts',
	'label'       => __( 'Base Color', 'congdongweb-admin' ),
	'description' => __( 'Used for all normal texts.', 'congdongweb-admin' ),
	'section'     => 'colors',
	'default'     => '#777',
	'transport'   => $transport,
) );

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'color',
	'settings'    => 'type_headings_color',
	'label'       => __( 'Headline Color', 'congdongweb-admin' ),
	'description' => __( 'Used for all headlines on white backgrounds. (H1, H2, H3 etc.)', 'congdongweb-admin' ),
	'section'     => 'colors',
	'default'     => '#555',
	'transport'   => $transport,
) );

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'color-alpha',
	'settings'    => 'color_divider',
	'label'       => __( 'Divider Color', 'congdongweb-admin' ),
	'description' => __( 'Used for dividers.', 'congdongweb-admin' ),
	'section'     => 'colors',
) );

Congdongweb_Option::add_field( '', array(
	'type'     => 'custom',
	'settings' => 'custom_title_type_links',
	'label'    => __( '', 'congdongweb-admin' ),
	'section'  => 'colors',
	'default'  => '<div class="options-title-divider">Links</div>',
) );

Congdongweb_Option::add_field( 'option', array(
	'type'      => 'color',
	'settings'  => 'color_links',
	'label'     => __( 'Link Colors', 'congdongweb-admin' ),
	'section'   => 'colors',
	'default'   => '#4e657b',
	'transport' => $transport,
) );

Congdongweb_Option::add_field( 'option', array(
	'type'      => 'color',
	'settings'  => 'color_links_hover',
	'label'     => __( 'Link Colors :hover', 'congdongweb-admin' ),
	'section'   => 'colors',
	'default'   => '#111',
	'transport' => $transport,
) );

Congdongweb_Option::add_field( 'option', array(
	'type'      => 'color',
	'settings'  => 'color_widget_links',
	'label'     => __( 'Widget Link Colors', 'congdongweb-admin' ),
	'section'   => 'colors',
	'default'   => '',
	'transport' => $transport,
) );

Congdongweb_Option::add_field( 'option', array(
	'type'      => 'color',
	'settings'  => 'color_widget_links_hover',
	'label'     => __( 'Widget Link Colors :hover', 'congdongweb-admin' ),
	'section'   => 'colors',
	'default'   => '',
	'transport' => $transport,
) );

if ( is_woocommerce_activated() ) {
	Congdongweb_Option::add_field( '', array(
		'type'     => 'custom',
		'settings' => 'custom_title_colors_shop',
		'label'    => __( '', 'congdongweb-admin' ),
		'section'  => 'colors',
		'default'  => '<div class="options-title-divider">Shop Colors</div>',
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'        => 'color',
		'settings'    => 'color_checkout',
		'label'       => __( 'Add to cart / Checkout buttons', 'congdongweb-admin' ),
		'description' => __( 'Change color for checkout buttons. Default is Secondary color', 'congdongweb-admin' ),
		'section'     => 'colors',
		'transport'   => $transport,
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'        => 'color',
		'settings'    => 'color_sale',
		'label'       => __( 'Sale bubble', 'congdongweb-admin' ),
		'description' => __( 'Change color of sale bubble. Default is Secondary color', 'congdongweb-admin' ),
		'section'     => 'colors',
		'transport'   => $transport,
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'        => 'color',
		'settings'    => 'color_new_bubble_auto',
		'label'       => __( 'New bubble (auto)', 'congdongweb-admin' ),
		'description' => __( 'Change color of the automatic "New" bubble.', 'congdongweb-admin' ),
		'section'     => 'colors',
		'transport'   => $transport,
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'        => 'color',
		'settings'    => 'color_new_bubble',
		'label'       => __( 'Custom bubble', 'congdongweb-admin' ),
		'description' => __( 'Change color of the custom bubble.', 'congdongweb-admin' ),
		'section'     => 'colors',
		'transport'   => $transport,
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'        => 'color',
		'settings'    => 'color_review',
		'label'       => __( 'Review Stars', 'congdongweb-admin' ),
		'description' => __( 'Change color of review stars', 'congdongweb-admin' ),
		'section'     => 'colors',
		'transport'   => $transport,
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'        => 'color',
		'settings'    => 'color_regular_price',
		'label'       => __( 'Regular Price', 'congdongweb-admin' ),
		'description' => __( 'Change color of the regular price of an on sale product.', 'congdongweb-admin' ),
		'section'     => 'colors',
		'transport'   => $transport,
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'        => 'color',
		'settings'    => 'color_sale_price',
		'label'       => __( 'Sale Price', 'congdongweb-admin' ),
		'description' => __( 'Change color of the sale price.', 'congdongweb-admin' ),
		'section'     => 'colors',
		'transport'   => $transport,
	) );
}
