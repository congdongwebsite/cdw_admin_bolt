<?php
/*****
 * Contact
 *************/
Congdongweb_Option::add_section( 'header_contact', array(
	'title'       =>  __( 'Contact', 'congdongweb-admin' ),
	'panel'       => 'header',
) );

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'radio-buttonset',
	'settings'     => 'contact_style',
	'label'       => __( 'Icon Style', 'congdongweb-admin' ),
	'section'     => 'header_contact',
	'transport' => $transport,
	'default'     => 'left',
	'choices'     => array(
		'left' => __( 'Icons Left', 'congdongweb-admin' ),
		'icons' => __( 'Icons Only', 'congdongweb-admin' ),
	),
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'text',
	'settings'     => 'contact_icon_size',
	'label'       => __( 'Icon Size', 'congdongweb-admin' ),
	'section'     => 'header_contact',
	'transport' => $transport,
	'default'     => '16px',
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'text',
	'settings'     => 'contact_phone',
	'label'       => __( 'Phone', 'congdongweb-admin' ),
	'section'     => 'header_contact',
	'transport' => $transport,
	'default'     => '+47 900 99 000',
));


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'text',
	'settings'     => 'contact_email',
	'label'       => __( 'E-mail', 'congdongweb-admin' ),
	'section'     => 'header_contact',
	'transport' => $transport,
	'default'     => 'youremail@gmail.com',
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'text',
	'settings'     => 'contact_email_label',
	'label'       => __( 'E-mail label', 'congdongweb-admin' ),
	'section'     => 'header_contact',
	'transport' => $transport,
	'default'     => '',
));


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'text',
	'settings'     => 'contact_location',
	'label'       => __( 'Location', 'congdongweb-admin' ),
	'help'        => __( 'Type in the location of your place or shop. It will open in a new window on Google Maps', 'congdongweb-admin' ),
	'section'     => 'header_contact',
	'transport' => $transport,
	'default'     => '',
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'text',
	'settings'     => 'contact_location_label',
	'label'       => __( 'Location label', 'congdongweb-admin' ),
	'section'     => 'header_contact',
	'transport' => $transport,
	'default'     => '',
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'text',
	'settings'     => 'contact_hours',
	'label'       => __( 'Open Hours', 'congdongweb-admin' ),
	'section'     => 'header_contact',
	'transport' => $transport,
	'default'     => '08:00 - 17:00',
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'textarea',
	'settings'     => 'contact_hours_details',
	'label'       => __( 'Open Hours - Details', 'congdongweb-admin' ),
	'section'     => 'header_contact',
	'transport' => $transport,
	'default'     => '',
));

function congdongweb_refresh_header_contact_partials( WP_Customize_Manager $wp_customize ) {

	if ( ! isset( $wp_customize->selective_refresh ) ) {
	      return;
	 }

	$wp_customize->selective_refresh->add_partial( 'header-contact', array(
	    'selector' => '.header-contact-wrapper',
	    'container_inclusive' => true,
	    'settings' => array('contact_location_label','contact_email_label','contact_icon_size','contact_style','contact_location','contact_phone','contact_email','contact_hours_details','contact_hours','contact_hours'),
	    'render_callback' => function() {
	         get_template_part('template-parts/header/partials/element','contact');
	    },
	) );
	
}
add_action( 'customize_register', 'congdongweb_refresh_header_contact_partials' );
