/*
Theme Name: <?php echo $new_theme_title, "\n"; ?>
Description: Theme is rewritten from Congdongweb, serving the products of Cong Dong Web
Author: CDW - Rewrite by UX-Themes
Template: congdongweb
Version: 1.1.1
*/

/*************** ADD CUSTOM CSS HERE.   ***************/


@media only screen and (max-width: 48em) {
/*************** ADD MOBILE ONLY CSS HERE  ***************/


}