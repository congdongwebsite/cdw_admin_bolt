<?php

Congdongweb_Option::add_field( 'option', array(
	'type'      => 'checkbox',
	'settings'  => 'woocommerce_store_notice_top',
	'label'     => __( 'Move store notice to the top', 'congdongweb-admin' ),
	'section'   => 'woocommerce_store_notice',
	'default'   => 0
) );