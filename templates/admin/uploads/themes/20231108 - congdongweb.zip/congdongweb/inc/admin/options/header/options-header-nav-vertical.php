<?php
/**
 * Options for nav vertical element.
 *
 * @package congdongweb
 */

Congdongweb_Option::add_section( 'header_nav_vertical', array(
	'title' => __( 'Vertical Menu', 'congdongweb' ),
	'panel' => 'header',
) );

/**
 * Add options.
 */
function congdongweb_customizer_header_nav_vertical_options() {
	Congdongweb_Option::add_field( '', array(
		'type'     => 'custom',
		'settings' => 'custom_title_header_nav_vertical_layout',
		'label'    => '',
		'section'  => 'header_nav_vertical',
		'default'  => '<div class="options-title-divider">Opener</div>',
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'radio-image',
		'settings'  => 'header_nav_vertical_icon_style',
		'label'     => __( 'Icon', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'default'   => 'plain',
		'transport' => congdongweb_customizer_transport(),
		'choices'   => array(
			''      => congdongweb_customizer_images_uri() . '/disabled.svg',
			'plain' => congdongweb_customizer_images_uri() . '/nav-icon-plain.svg',
		),
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'slider',
		'settings'  => 'header_nav_vertical_height',
		'label'     => __( 'Height', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => '50',
		'choices'   => array(
			'min'  => '10',
			'max'  => '500',
			'step' => '1',
		),
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'slider',
		'settings'  => 'header_nav_vertical_width',
		'label'     => __( 'Width', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => '250',
		'choices'   => array(
			'min'  => '10',
			'max'  => '500',
			'step' => '1',
		),
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'text',
		'settings'  => 'header_nav_vertical_tagline',
		'label'     => __( 'Tag line', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => '',
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'text',
		'settings'  => 'header_nav_vertical_text',
		'label'     => __( 'Text', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => '',
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'radio-image',
		'settings'  => 'header_nav_vertical_text_color',
		'label'     => __( 'Text base color', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'default'   => 'dark',
		'transport' => congdongweb_customizer_transport(),
		'choices'   => array(
			'dark'  => congdongweb_customizer_images_uri() . '/text-light.svg',
			'light' => congdongweb_customizer_images_uri() . '/text-dark.svg',
		),
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'color-alpha',
		'alpha'     => true,
		'settings'  => 'header_nav_vertical_color',
		'label'     => __( 'Color', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => '',
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'color-alpha',
		'alpha'     => true,
		'settings'  => 'header_nav_vertical_bg_color',
		'label'     => __( 'Background color', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => '',
	) );

	Congdongweb_Option::add_field( '', array(
		'type'     => 'custom',
		'settings' => 'custom_title_header_nav_vertical_fly_out',
		'label'    => '',
		'section'  => 'header_nav_vertical',
		'default'  => '<div class="options-title-divider">Fly out</div>',
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'checkbox',
		'settings'  => 'header_nav_vertical_fly_out_frontpage',
		'label'     => __( 'Keep open on front page', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => 1,
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'checkbox',
		'settings'  => 'header_nav_vertical_fly_out_shadow',
		'label'     => __( 'Add shadow', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => 1,
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'slider',
		'settings'  => 'header_nav_vertical_fly_out_width',
		'label'     => __( 'Width', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => '250',
		'choices'   => array(
			'min'  => '10',
			'max'  => '500',
			'step' => '1',
		),
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'color-alpha',
		'alpha'     => true,
		'settings'  => 'header_nav_vertical_fly_out_bg_color',
		'label'     => __( 'Background color', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => '',
	) );

	Congdongweb_Option::add_field( '', array(
		'type'     => 'custom',
		'settings' => 'custom_title_header_nav_vertical_fly_out_navigation',
		'label'    => '',
		'section'  => 'header_nav_vertical',
		'default'  => '<div class="options-title-divider">Fly out navigation</div>',
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'checkbox',
		'settings'  => 'header_nav_vertical_fly_out_nav_divider',
		'label'     => __( 'Divider', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => 1,
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'slider',
		'settings'  => 'header_nav_vertical_fly_out_nav_height',
		'label'     => __( 'Nav height', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => 0,
		'choices'   => array(
			'min'  => 0,
			'max'  => 200,
			'step' => 1,
		),
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'radio-image',
		'settings'  => 'header_nav_vertical_fly_out_text_color',
		'label'     => __( 'Text base color', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'default'   => 'light',
		'transport' => congdongweb_customizer_transport(),
		'choices'   => array(
			'dark'  => congdongweb_customizer_images_uri() . '/text-light.svg',
			'light' => congdongweb_customizer_images_uri() . '/text-dark.svg',
		),
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'color-alpha',
		'alpha'     => true,
		'settings'  => 'header_nav_vertical_fly_out_nav_color',
		'label'     => __( 'Nav color', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => '',
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'color-alpha',
		'alpha'     => true,
		'settings'  => 'header_nav_vertical_fly_out_nav_color_hover',
		'label'     => __( 'Nav color :hover', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => '',
	) );

	Congdongweb_Option::add_field( 'option', array(
		'type'      => 'color-alpha',
		'alpha'     => true,
		'settings'  => 'header_nav_vertical_fly_out_nav_bg_color_hover',
		'label'     => __( 'Nav background color :hover', 'congdongweb' ),
		'section'   => 'header_nav_vertical',
		'transport' => congdongweb_customizer_transport(),
		'default'   => '',
	) );
}

add_action( 'init', 'congdongweb_customizer_header_nav_vertical_options' );

/**
 * Refresh partials.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function congdongweb_refresh_header_nav_vertical_partials( WP_Customize_Manager $wp_customize ) {
	if ( ! isset( $wp_customize->selective_refresh ) ) {
		return;
	}

	$wp_customize->selective_refresh->add_partial( 'header-vertical-menu', array(
		'selector'            => '.header-vertical-menu',
		'container_inclusive' => true,
		'settings'            => array(
			'header_nav_vertical_icon_style',
			'header_nav_vertical_tagline',
			'header_nav_vertical_text',
		),
		'render_callback'     => function () {
			get_template_part( 'template-parts/header/partials/element', 'nav-vertical' );
		},
	) );

	$wp_customize->selective_refresh->add_partial( 'header-vertical-menu-refresh-css', array(
		'selector'        => 'head > style#custom-css',
		'settings'        => array(
			'header_nav_vertical_color',
			'header_nav_vertical_bg_color',
			'header_nav_vertical_fly_out_bg_color',
			'header_nav_vertical_fly_out_nav_divider',
			'header_nav_vertical_fly_out_nav_height',
			'header_nav_vertical_fly_out_nav_color',
			'header_nav_vertical_fly_out_nav_color_hover',
			'header_nav_vertical_fly_out_nav_bg_color_hover',
		),
		'render_callback' => function () {
			congdongweb_custom_css();
		},
	) );
}

add_action( 'customize_register', 'congdongweb_refresh_header_nav_vertical_partials' );
