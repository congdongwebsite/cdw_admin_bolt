<?php

/*************
 * Header Mobile
 *************/

Congdongweb_Option::add_section( 'header_mobile', array(
	'title'       => __( 'Header Mobile Menu / Overlay', 'congdongweb-admin' ),
	'panel'       => 'header',
	//'description' => __( 'This is the section description', 'congdongweb-admin' ),
) );


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'slider',
	'settings'     => 'header_height_mobile',
	'label'       => __( 'Mobile Header Height', 'congdongweb-admin' ),
	//'description' => __( 'This is the control description', 'congdongweb-admin' ),
	//'help'        => __( 'This is some extra help. You can use this to add some additional instructions for users. The main description should go in the "description" of the field, this is only to be used for help tips.', 'congdongweb-admin' ),
	'section'     => 'header_mobile',
	'default'     => '70',
	'choices'     => array(
		'min'  => 30,
		'max'  => 500,
		'step' => 1
	),
	'transport' => 'postMessage'
));

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'radio-image',
	'settings'     => 'logo_position_mobile',
	'label'       => __( 'Logo position', 'congdongweb-admin' ),
	'section'     => 'header_mobile',
	'transport' => $transport,
	'default'     => 'center',
	'choices'     => array(
		'left' => $image_url . 'logo-left.svg',
		'center' => $image_url . 'logo-right.svg',
	),
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'radio-image',
	'settings'     => 'menu_icon_style',
	'label'       => __( 'Menu Icon Style', 'congdongweb-admin' ),
	'section'     => 'header_mobile',
	'default'     => '',
	'transport' => $transport,
	'choices'     => array(
		'' => $image_url . 'nav-icon-plain.svg',
		'outline' => $image_url . 'nav-icon-outline.svg',
		'fill' => $image_url . 'nav-icon-fill.svg',
		'fill-round' => $image_url . 'nav-icon-fill-round.svg',
		'outline-round' => $image_url . 'nav-icon-outline-round.svg',
	),
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'checkbox',
	'settings'     => 'menu_icon_title',
	'label'       => __( 'Show Menu title', 'congdongweb-admin' ),
	'section'     => 'header_mobile',
	'transport' => $transport,
	'default'     => 0,
));

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'radio-image',
	'settings'     => 'mobile_overlay',
	'label'       => __( 'Menu Overlay', 'congdongweb-admin' ),
	'section'     => 'header_mobile',
	'transport'	  => $transport,
	'default'     => 'left',
	'choices'     => array(
		'left' => $image_url . 'overlay-left.svg',
		'right' => $image_url . 'overlay-right.svg',
		'center' => $image_url . 'overlay-center.svg'
	),
));

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'radio',
	'settings'    => 'mobile_submenu_parent_behavior',
	'label'       => __( 'Menu item behavior', 'congdongweb' ),
	'description' => __( 'Click behavior for menu items with a submenu', 'congdongweb' ),
	'section'     => 'header_mobile',
	'transport'   => 'refresh',
	'default'     => '',
	'choices'     => array(
		''       => __( 'Open link', 'congdongweb' ),
		'toggle' => __( 'Toggle submenu', 'congdongweb' ),
	),
) );

Congdongweb_Option::add_field( 'option', array(
	'type'            => 'radio',
	'settings'        => 'mobile_submenu_effect',
	'label'           => __( 'Submenu effect', 'congdongweb' ),
	'section'         => 'header_mobile',
	'transport'       => 'refresh',
	'default'         => 'accordion',
	'choices'         => array(
		'accordion' => __( 'Accordion', 'congdongweb' ),
		'slide'     => __( 'Slide', 'congdongweb' ),
	),
	'active_callback' => array(
		array(
			'setting'  => 'mobile_overlay',
			'operator' => '!=',
			'value'    => 'center',
		),
	),
) );

Congdongweb_Option::add_field( 'option', array(
	'type'            => 'select',
	'settings'        => 'mobile_submenu_levels',
	'label'           => __( 'Submenu levels', 'congdongweb' ),
	'section'         => 'header_mobile',
	'transport'       => 'refresh',
	'default'         => '1',
	'choices'         => array(
		'1' => __( '1 level', 'congdongweb' ),
		'2' => __( '2 levels', 'congdongweb' ),
	),
	'active_callback' => array(
		array(
			'setting'  => 'mobile_overlay',
			'operator' => '!=',
			'value'    => 'center',
		),
		array(
			'setting'  => 'mobile_submenu_effect',
			'operator' => '===',
			'value'    => 'slide',
		),
	),
) );

Congdongweb_Option::add_field( 'option', array(
	'type'              => 'textarea',
	'settings'          => 'mobile_sidebar_top_content',
	'label'             => __( 'Top content', 'congdongweb' ),
	'section'           => 'header_mobile',
	'sanitize_callback' => 'congdongweb_custom_sanitize',
	'default'           => '',
) );

Congdongweb_Option::add_field( 'option', array(
	'type'     => 'radio-buttonset',
	'settings' => 'mobile_sidebar_tabs',
	'label'    => __( 'Tabs', 'congdongweb' ),
	'section'  => 'header_mobile',
	'default'  => '0',
	'choices'  => array(
		'0' => __( 'None', 'congdongweb' ),
		'2' => __( '2 Tabs', 'congdongweb' ),
	),
) );

Congdongweb_Option::add_field( 'option', array(
	'type'            => 'text',
	'settings'        => 'mobile_sidebar_tab_text',
	'label'           => __( 'Tab 1 text', 'congdongweb' ),
	'section'         => 'header_mobile',
	'default'         => '',
	'active_callback' => array(
		array(
			'setting'  => 'mobile_sidebar_tabs',
			'operator' => '!=',
			'value'    => false,
		),
	),
) );

Congdongweb_Option::add_field( 'option',  array(
  'type'        => 'sortable',
  'settings'     => 'mobile_sidebar',
  'label'       => __( 'Menu elements', 'congdongweb' ),
  'section'     => 'header_mobile',
  'transport'   => $transport,
  'multiple' => 10,
  'default'     => congdongweb_header_mobile_sidebar(),
  'choices'     => $nav_elements
));

Congdongweb_Option::add_field( 'option', array(
	'type'            => 'text',
	'settings'        => 'mobile_sidebar_tab_2_text',
	'label'           => __( 'Tab 2 text', 'congdongweb' ),
	'section'         => 'header_mobile',
	'default'         => '',
	'active_callback' => array(
		array(
			'setting'  => 'mobile_sidebar_tabs',
			'operator' => '!=',
			'value'    => false,
		),
	),
) );

Congdongweb_Option::add_field( 'option', array(
	'type'            => 'sortable',
	'settings'        => 'mobile_sidebar_tab_2',
	'label'           => __( 'Menu elements tab 2', 'congdongweb' ),
	'section'         => 'header_mobile',
	'transport'       => congdongweb_customizer_transport(),
	'multiple'        => 10,
	'default'         => '',
	'choices'         => $nav_elements,
	'active_callback' => array(
		array(
			'setting'  => 'mobile_sidebar_tabs',
			'operator' => '!=',
			'value'    => false,
		),
	),
) );

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'radio-image',
	'settings'     => 'mobile_overlay_color',
	'label'       => __( 'Overlay Color', 'congdongweb-admin' ),
	'section'     => 'header_mobile',
	'transport'	  => $transport,
	'default'     => '',
	'choices'     => array(
		'' => $image_url . 'text-dark.svg',
		'dark' => $image_url . 'text-light.svg',
	),
));


Congdongweb_Option::add_field( 'option',  array(
    'type'        => 'color-alpha',
    'settings'     => 'mobile_overlay_bg',
    'label'       => __( 'Background Color', 'congdongweb-admin' ),
	'section'     => 'header_mobile',
	'default'     => '',
	'transport' => 'postMessage'
));
