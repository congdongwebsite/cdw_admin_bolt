<?php

Congdongweb_Option::add_panel( 'style', array(
  'title'       => __( 'Style', 'congdongweb-admin' ),
) );

Congdongweb_Option::add_section( 'custom-css', array(
	'title'       => __( 'Custom CSS', 'congdongweb-admin' ),
	'panel'       => 'style',
) );

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'code',
	'settings'     => 'html_custom_css',
	'label'       => __( 'Custom CSS', 'congdongweb-admin' ),
	'section'     => 'custom-css',
	'transport'   => $transport,
	'placeholder' => '.add-css-here{}',
  'choices'     => array(
    'language' => 'css',
  ),
));

Congdongweb_Option::add_field( 'option',  array(
  'type'        => 'code',
	'settings'     => 'html_custom_css_tablet',
	'label'       => __( 'Custom Tablet CSS', 'congdongweb-admin' ),
	'section'     => 'custom-css',
	'default'     => '',
  'placeholder' => '.add-css-here{}',
	'transport'   => $transport,
  'choices'     => array(
    'language' => 'css',
  ),
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'code',
	'settings'     => 'html_custom_css_mobile',
	'label'       => __( 'Custom Mobile CSS', 'congdongweb-admin' ),
	'section'     => 'custom-css',
	'default'     => '',
  'placeholder' => '.add-css-here{}',
	'transport'   => $transport,
  'choices'     => array(
    'language' => 'css',
  ),
));
