<?php

/**
 * Congdongweb Admin Panel
 */
class Congdongweb_Admin
{

	/**
	 * Sets up the welcome screen
	 */
	public function __construct()
	{
		add_action('admin_menu', array($this, 'congdongweb_panel_register_menu'));
		add_action('admin_enqueue_scripts', array($this, 'congdongweb_panel_style'));

		add_action('current_screen', array($this, 'render_version_info_iframe'));
	}


	public function render_version_info_iframe($screen)
	{
		if ($screen->base === 'admin_page_congdongweb-version-info') {
			$version = isset($_GET['version']) ? wp_unslash($_GET['version']) : '';
			include get_template_directory() . '/template-parts/admin/congdongweb/version-info-iframe.php';
			die;
		}
	}
	/**
	 * Load welcome screen css.
	 *
	 * @since  1.4.4
	 */
	public function congdongweb_panel_style()
	{
		$uri     = get_template_directory_uri();
		$theme   = wp_get_theme(get_template());
		$version = $theme->get('Version');

		wp_enqueue_style('congdongweb-panel-css', $uri . '/inc/admin/panel/panel.css', array(), $version);
		wp_enqueue_script('congdongweb-panel', $uri . '/inc/admin/panel/panel.js', array('jquery', 'wp-date'), $version, true);
		wp_localize_script('congdongweb-panel', 'congdongwebPanelOptions', array(
			'errorMessage' => __('Sorry, an error occurred while accessing the API.', 'congdongweb'),
		));
	}


	/**
	 * Creates the dashboard page
	 * @see  add_theme_page()
	 * @since 1.0.0
	 */
	public function congdongweb_panel_register_menu()
	{
		add_menu_page('Welcome to ' . wp_get_theme(), 'C.D.W', 'manage_options', 'congdongweb-panel', array($this, 'congdongweb_panel_support'), get_template_directory_uri() . '/assets/img/logo-icon.svg', '2');
		add_submenu_page('congdongweb-panel', 'Hỗ trợ', 'Hỗ trợ', 'manage_options', 'congdongweb-panel-support', array($this, 'congdongweb_panel_support'));
		add_submenu_page('congdongweb-panel', 'Tình trạng', 'Tình trạng', 'manage_options', 'congdongweb-panel-status', array($this, 'congdongweb_panel_status'));
		add_submenu_page('congdongweb-panel', 'Log', 'Log', 'manage_options', 'congdongweb-panel-changelog', array($this, 'congdongweb_panel_changelog'));
		add_submenu_page('congdongweb-panel', 'Tùy chọn', 'Tùy chọn', 'manage_options', 'congdongweb-panel-options', array($this, 'congdongweb_panel_options'));
		add_submenu_page('congdongweb-panel', '', 'Tùy chỉnh', 'manage_options', 'customize.php');
		add_submenu_page(null, '', '', 'manage_options', 'congdongweb-version-info', '__return_empty_string');
	}

	public function congdongweb_panel_options()
	{
?>
		<div class="congdongweb-panel">
			<div class="wrap about-wrap">
				<?php require get_template_directory() . '/inc/admin/panel/sections/top.php'; ?>
				<?php require get_template_directory() . '/inc/admin/panel/sections/tab-options.php'; ?>
			</div>
		</div>
	<?php
	}

	public function congdongweb_panel_support()
	{
	?>
		<div class="congdongweb-panel">
			<div class="wrap about-wrap">
				<?php require get_template_directory() . '/inc/admin/panel/sections/top.php'; ?>
				<?php require get_template_directory() . '/inc/admin/panel/sections/tab-support.php'; ?>
			</div>
		</div>
	<?php
	}

	public function congdongweb_panel_status()
	{
	?>
		<div class="congdongweb-panel">
			<div class="wrap about-wrap">
				<?php require get_template_directory() . '/inc/admin/panel/sections/top.php'; ?>
				<?php require get_template_directory() . '/inc/admin/panel/sections/tab-status.php'; ?>
			</div>
		</div>
	<?php
	}

	public function congdongweb_panel_changelog()
	{
	?>
		<div class="congdongweb-panel">
			<div class="wrap about-wrap">
				<?php require get_template_directory() . '/inc/admin/panel/sections/top.php'; ?>
				<?php require get_template_directory() . '/inc/admin/panel/sections/tab-changelog.php'; ?>
			</div>
		</div>
<?php
	}
}

$GLOBALS['Congdongweb_Admin'] = new Congdongweb_Admin();
