<?php


Congdongweb_Option::add_section( 'payment-icons', array(
	'title'       => __( 'Payments Icons', 'congdongweb-admin' ),
	'description' => 'Note: This is not where you select payment methods. These are graphical icons that show which payment methods your shop supports. You can add these anywhere by using the shortcode [ux_payment_icons]',
	'panel'       => 'woocommerce',
) );

Congdongweb_Option::add_field( 'option', array(
	'type'      => 'sortable',
	'settings'  => 'payment_icons',
	'label'     => __( 'Payment Icons', 'congdongweb-admin' ),
	'section'   => 'payment-icons',
	'transport' => $transport,
	'multiple'  => 99,
	'default'   => array( 'visa', 'paypal', 'stripe', 'mastercard', 'cashondelivery' ),
	'choices'   => congdongweb_get_payment_icons_list(),
) );

Congdongweb_Option::add_field( 'option', array(
	'type'      => 'image',
	'settings'  => 'payment_icons_custom',
	'label'     => __( 'Custom Icons (Replace)', 'congdongweb-admin' ),
	'section'   => 'payment-icons',
	'default'   => '',
	'transport' => $transport,
) );

Congdongweb_Option::add_field( 'option', array(
	'type'        => 'multicheck',
	'settings'    => 'payment_icons_placement',
	'label'       => __( 'Placement', 'congdongweb-admin' ),
	'description' => __( 'Select where you want to show the payment icons', 'congdongweb-admin' ),
	'section'     => 'payment-icons',
	'default'     => '',
	'choices'     => array(
		'footer' => __( 'Absolute Footer', 'congdongweb-admin' ),
		'cart'   => __( 'Cart Sidebar', 'congdongweb-admin' ),
	),
) );
