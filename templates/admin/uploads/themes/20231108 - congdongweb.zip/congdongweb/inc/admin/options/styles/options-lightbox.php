<?php

Congdongweb_Option::add_section( 'lightbox', array(
	'title' => __( 'Image Lightbox', 'congdongweb-admin' ),
	'panel' => 'style',
) );

Congdongweb_Option::add_field( 'option', array(
	'type'     => 'checkbox',
	'settings' => 'congdongweb_lightbox',
	'label'    => __( 'Enable Congdongweb Lightbox', 'congdongweb-admin' ),
	'section'  => 'lightbox',
	'default'  => 1,
) );

Congdongweb_Option::add_field( 'option', array(
	'type'            => 'color',
	'settings'        => 'congdongweb_lightbox_bg',
	'label'           => __( 'Lightbox background color', 'congdongweb-admin' ),
	'section'         => 'lightbox',
	'transport'       => $transport,
	'default'         => '',
	'active_callback' => array(
		array(
			'setting'  => 'congdongweb_lightbox',
			'operator' => '==',
			'value'    => true,
		),
	),
) );

Congdongweb_Option::add_field( '', array(
	'type'            => 'custom',
	'settings'        => 'custom_lightbox_gallery_layout',
	'label'           => '',
	'section'         => 'lightbox',
	'default'         => '<div class="options-title-divider">Gallery</div>',
	'active_callback' => array(
		array(
			'setting'  => 'congdongweb_lightbox',
			'operator' => '==',
			'value'    => true,
		),
	),
) );

Congdongweb_Option::add_field( 'option', array(
	'type'            => 'checkbox',
	'settings'        => 'congdongweb_lightbox_multi_gallery',
	'label'           => __( 'Use multiple galleries on a page', 'congdongweb-admin' ),
	'description'     => __( 'When enabled, lightbox galleries on a page are treated separately, else combined in one gallery.', 'congdongweb-admin' ),
	'section'         => 'lightbox',
	'default'         => 0,
	'active_callback' => array(
		array(
			'setting'  => 'congdongweb_lightbox',
			'operator' => '==',
			'value'    => true,
		),
	),
) );
