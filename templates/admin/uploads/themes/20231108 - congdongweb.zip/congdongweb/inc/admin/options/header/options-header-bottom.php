<?php

/*************
 * Header Main
 *************/

Congdongweb_Option::add_section( 'bottom_bar', array(
	'title'       => __( 'Header Bottom', 'congdongweb-admin' ),
	'panel'       => 'header',
	//'description' => __( 'This is the section description', 'congdongweb-admin' ),
) );


Congdongweb_Option::add_field( '', array(
    'type'        => 'custom',
    'settings' => 'custom_title_header_bottom_layout',
    'label'       => __( '', 'congdongweb-admin' ),
	'section'     => 'bottom_bar',
    'default'     => '<div class="options-title-divider">Layout</div>',
) );


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'slider',
	'settings'     => 'header_bottom_height',
	'label'       => __( 'Height', 'congdongweb-admin' ),
	'section'     => 'bottom_bar',
	'default' => '',
	'choices'     => array(
		'min'  => 10,
		'max'  => 100,
		'step' => 1
	),
	'transport' => 'postMessage',
));


Congdongweb_Option::add_field( 'option',  array(
    'type'        => 'color-alpha',
    'settings'     => 'nav_position_bg',
    'label'       => __( 'Background color', 'congdongweb-admin' ),
    'section'     => 'bottom_bar',
	'default'     => "#f1f1f1",
	'transport' => 'postMessage',
));



Congdongweb_Option::add_field( '', array(
    'type'        => 'custom',
    'settings' => 'custom_title_header_bottom_nav',
    'label'       => __( '', 'congdongweb-admin' ),
	'section'     => 'bottom_bar',
    'default'     => '<div class="options-title-divider">Navigation</div>',
) );

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'radio-image',
	'settings'     => 'nav_style_bottom',
	'label'       => __( 'Nav Style', 'congdongweb-admin' ),
	'section'     => 'bottom_bar',
	'default'     => '',
	'transport' => $transport,
	'choices'     => $nav_styles_img
));


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'slider',
	'settings'     => 'nav_height_bottom',
	'label'       => __( 'Nav Height', 'congdongweb-admin' ),
	'section'     => 'bottom_bar',
	'default' => 16,
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1
	),
	'transport' => 'postMessage',
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'radio-buttonset',
	'settings'     => 'nav_size_bottom',
	'label'       => __( 'Nav Size', 'congdongweb-admin' ),
	'section'     => 'bottom_bar',
	'transport' => $transport,
	'default'     => '',
	'choices'     => $nav_sizes
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'radio-buttonset',
	'settings'     => 'nav_spacing_bottom',
	'label'       => __( 'Nav Spacing', 'congdongweb-admin' ),
	'section'     => 'bottom_bar',
	'transport' => $transport,
	'default'     => '',
	'choices'     => $nav_sizes
));

Congdongweb_Option::add_field( 'option',  array(
		'type'        => 'checkbox',
		'settings'     => 'nav_uppercase_bottom',
		'label'       => __( 'Uppercase', 'congdongweb-admin' ),
		'section'     => 'bottom_bar',
	    'transport' => $transport,
		'default'     => 1,
));

Congdongweb_Option::add_field( 'option', array(
	'type'     => 'checkbox',
	'settings' => 'nav_bottom_body_overlay',
	'label'    => __( 'Add overlay on hover', 'congdongweb-admin' ),
	'section'  => 'bottom_bar',
	'default'  => 0,
) );

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'radio-image',
	'settings'     => 'nav_position_color',
	'label'       => __( 'Nav Base Color', 'congdongweb-admin' ),
	'section'     => 'bottom_bar',
	'default'     => 'light',
	'transport' => 'postMessage',
	'choices'     => array(
		'dark' => $image_url . 'text-light.svg',
		'light' => $image_url . 'text-dark.svg'
	),
));

Congdongweb_Option::add_field( 'option',  array(
    'type'        => 'color',
    'settings'     => 'type_nav_bottom_color',
    'label'       => __( 'Nav Color', 'congdongweb-admin' ),
	'section'     => 'bottom_bar',
    'transport' => $transport
));

Congdongweb_Option::add_field( 'option',  array(
    'type'        => 'color',
    'settings'     => 'type_nav_bottom_color_hover',
    'label'       => __( 'Nav Color :hover', 'congdongweb-admin' ),
	'section'     => 'bottom_bar',
    'transport' => $transport
));


