<?php

/**
 * Welcome screen getting started template
 */

?>
<div id="tab-support" class="coltwo-col panel congdongweb-panel">
	<div class="cols">

		<div class="inner-panel" style="text-align: center;">
			<img style="width:100px; margin:30px 15px 0;" src="<?php echo get_template_directory_uri() . '/inc/admin/panel/img/emailsupport.png'; ?>" />
			<h3>Dịch vụ thiết kế web</h3>
			<p>Thiết kế trang web theo yêu cầu.</p>

		</div>
		<div class="inner-panel" style="text-align: center;">
			<img style="width:100px; margin:30px 15px 0;" src="<?php echo get_template_directory_uri() . '/inc/admin/panel/img/videos.png'; ?>" />
			<h3>Kho giao diện</h3>
			<p>Kho giao diện cho khách lựa chọn.</p>
		</div>

		<div class="inner-panel" style="text-align: center;">
			<img style="width:100px; margin:30px 15px 0;" src="<?php echo get_template_directory_uri() . '/inc/admin/panel/img/documentation.png'; ?>" />
			<h3>Kho plugin</h3>
			<p>Tất cả các plugin được phát triển bởi.</p>
		</div>
	</div>

	<div class="cols">
		<div class="inner-panel" style="text-align: center;">
			<img style="width:100px; margin:30px 15px 0;" src="<?php echo get_template_directory_uri() . '/inc/admin/panel/img/emailsupport.png'; ?>" />
			<h3>Mua tên miền</h3>
			<p>Mua tên miền online.</p>

		</div>
		<div class="inner-panel" style="text-align: center;">
			<img style="width:100px; margin:30px 15px 0;" src="<?php echo get_template_directory_uri() . '/inc/admin/panel/img/emailsupport.png'; ?>" />
			<h3>Email Server</h3>
			<p>Đăng ký email server.</p>

		</div>
		<div class="inner-panel" style="text-align: center;">
			<img style="width:100px; margin:30px 15px 0;" src="<?php echo get_template_directory_uri() . '/inc/admin/panel/img/emailsupport.png'; ?>" />
			<h3>VPS Server</h3>
			<p>Đăng ký VPS server.</p>
		</div>

	</div>

</div>