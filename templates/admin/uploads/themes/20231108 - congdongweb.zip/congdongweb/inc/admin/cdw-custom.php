<?php

function cdw_footer_version()
{
    return sprintf(__('Wordpress %s'), get_bloginfo('version', 'display')) . ' - ' . sprintf(__('Cộng Đồng Web %s'), THEMEVERSION);
}
add_filter('update_footer', 'cdw_footer_version', 20);

function cdw_admin_footer_text($text)
{
    return sprintf(__('Chào mừng bạn đến với website %s.'), wp_get_theme());
}
add_filter('admin_footer_text', 'cdw_admin_footer_text');

function cdw_login_headerurl()
{
    return get_home_url();
}
add_filter('login_headerurl', 'cdw_login_headerurl', 10, 1);

function cdw_login_form_defaults($defaults)
{
    $defaults['value_remember'] = true;
    return $defaults;
}
add_filter('login_form_defaults', 'cdw_login_form_defaults', 10, 1);

function wordpress_custom_login_logo()
{
    $logo_url = get_site_logo();
    $wp_logo_height = '100px';
    $wp_logo_width = '100%';

    if (!empty($logo_url)) {
        echo '<style type="text/css">' .
            'h1 a {
                    background-image:url(' . $logo_url . ') !important;
                    height:' . $wp_logo_height . ' !important;
                    width:' . $wp_logo_width . ' !important;    
                    background-size: contain !important;
                    line-height:inherit !important;
                    }' .
            '</style>';
    }
}
add_action('login_head', 'wordpress_custom_login_logo');
function remove_dashboard_widgets()
{
    global $wp_meta_boxes;

    // echo '<pre>';
    // var_dump($wp_meta_boxes);
    // echo '</pre>';

    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
}

add_action('wp_dashboard_setup', 'remove_dashboard_widgets');

function cdw_remove_action()
{
    remove_action('admin_bar_menu', 'wp_admin_bar_wp_menu', 10);
    remove_action('admin_bar_menu', 'wp_admin_bar_site_menu', 30);
    remove_action('admin_bar_menu', 'wp_admin_bar_comments_menu', 60);
}
add_action('add_admin_bar_menus', 'cdw_remove_action');

function cdw_meta_color_title_browser()
{
?>
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="<?php echo Congdongweb_Default::COLOR_PRIMARY; ?>">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="<?php echo Congdongweb_Default::COLOR_PRIMARY; ?>">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="<?php echo Congdongweb_Default::COLOR_PRIMARY; ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">

<?php
}
add_action('wp_head', 'cdw_meta_color_title_browser');

function get_site_logo()
{
    $image_url = get_template_directory_uri() . '/assets/img/logo.png';
    $site_logo = do_shortcode(get_theme_mod('site_logo', $image_url));
    if (is_numeric($site_logo)) {
        $image_src = wp_get_attachment_image_src($site_logo, 'large');
        if (!empty($image_src)) {
            $image_url = $image_src[0];
        }
    } else if (is_string($site_logo)) {
        $image_url = $site_logo;
    }
    return apply_filters('congdongweb_setup_logo_image', $image_url);
}
