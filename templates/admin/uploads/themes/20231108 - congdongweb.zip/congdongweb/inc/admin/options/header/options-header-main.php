<?php

/*************
 * Header Main
 *************/

Congdongweb_Option::add_section( 'main_bar', array(
	'title'       => __( 'Header Main', 'congdongweb-admin' ),
	'panel'       => 'header',
	//'description' => __( 'This is the section description', 'congdongweb-admin' ),
) );

Congdongweb_Option::add_field( '', array(
    'type'        => 'custom',
    'settings' => 'custom_title_header_layout',
    'label'       => __( '', 'congdongweb-admin' ),
    'section'     => 'main_bar',
    'default'     => '<div class="options-title-divider">Layout</div>',
) );


Congdongweb_Option::add_field( 'option', array(
	'type'        => 'radio-image',
	'settings'     => 'header_width',
	'label'       => __( 'Header Width', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'default'     => 'container',
	'transport' => 'postMessage',
	'choices'     => array(
		'container' => $image_url . 'container.svg',
		'full-width' => $image_url . 'full-width.svg'
	),
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'slider',
	'settings'     => 'header_height',
	'label'       => __( 'Height', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'default'     => 90,
	'choices'     => array(
		'min'  => 30,
		'max'  => 500,
		'step' => 1
	),
	'transport' => 'postMessage'
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'radio-image',
	'settings'     => 'header_color',
	'label'       => __( 'Text color', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'default'     => 'light',
	'transport' => 'postMessage',
	'choices'     => array(
		'dark' => $image_url . 'text-light.svg',
		'light' => $image_url . 'text-dark.svg'
	),
));


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'color-alpha',
    'alpha' => true,
    'settings'     => 'header_bg',
    'label'       => __( 'Background Color', 'congdongweb-admin' ),
    'section'     => 'main_bar',
	'default'     => 'rgba(255,255,255,0.9)',
	'transport' => 'postMessage'
));


Congdongweb_Option::add_field( 'option',  array(
    'type'        => 'image',
    'settings'     => 'header_bg_img',
    'label'       => __( 'Background Image', 'congdongweb-admin' ),
    'help' => __( 'Image is added to .header container. Try set a header background with opacity if you can not see the background image. (Drag the alpha slider in the background selector)', 'congdongweb-admin' ),
    'section'     => 'main_bar',
	'default'     => "",
	'transport' => 'postMessage',
));


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'radio-buttonset',
	'settings'     => 'header_bg_img_repeat',
	'label'       => __( 'Background Repeat', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'default'     => 'repeat',
	'choices'     => $bg_repeat,
	'transport' => 'postMessage',
	'active_callback' => array(
		array(
			'setting'  => 'header_bg_img',
			'operator' => '!==',
			'value'    => '',
		),
	),
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'checkbox',
	'settings'     => 'box_shadow_header',
	'label'       => __( 'Add Shadow', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'transport' => 'postMessage',
	'default'     => 0,
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'checkbox',
	'settings'     => 'header_divider',
	'label'       => __( 'Add Divider', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'transport' => $transport,
	'default'     => 1,
));


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'textarea',
	'settings'     => 'html_after_header',
	'label'       => __( 'HTML after header', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'default'     => '',
	'sanitize_callback' => 'congdongweb_custom_sanitize',
));


Congdongweb_Option::add_field( '', array(
    'type'        => 'custom',
    'settings' => 'custom_title_nav',
    'label'       => __( '', 'congdongweb-admin' ),
    'section'     => 'main_bar',
    'default'     => '<div class="options-title-divider">Navigation</div>',
) );


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'radio-image',
	'settings'     => 'nav_style',
	'label'       => __( 'Navigation Style', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'default'     => '',
	'transport' => $transport,
	'choices'     => $nav_styles_img
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'radio-buttonset',
	'settings'     => 'nav_size',
	'label'       => __( 'Nav Size', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'transport' => $transport,
	'default'     => '',
	'choices'     => $nav_sizes
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'radio-buttonset',
	'settings'     => 'nav_spacing',
	'label'       => __( 'Nav Spacing', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'transport' => $transport,
	'default'     => '',
	'choices'     => $nav_sizes
));


Congdongweb_Option::add_field( 'option',  array(
		'type'        => 'checkbox',
		'settings'     => 'nav_uppercase',
		'label'       => __( 'Uppercase', 'congdongweb-admin' ),
		'section'     => 'main_bar',
	    'transport' => $transport,
		'default'     => 1,
));

Congdongweb_Option::add_field( 'option', array(
	'type'     => 'checkbox',
	'settings' => 'nav_body_overlay',
	'label'    => __( 'Add overlay on hover', 'congdongweb-admin' ),
	'section'  => 'main_bar',
	'default'  => 0,
) );


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'slider',
	'settings'     => 'nav_height',
	'label'       => __( 'Nav Height', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'default' => 16,
	'choices'     => array(
		'min'  => 0,
		'max'  => 500,
		'step' => 1
	),
	'transport' => 'postMessage',
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'slider',
	'settings'     => 'nav_push',
	'label'       => __( 'Nav Push', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'default' => 0,
	'choices'     => array(
		'min'  => -50,
		'max'  => 50,
		'step' => 1
	),
	'transport' => 'postMessage',
));

Congdongweb_Option::add_field( 'option',  array(
    'type'        => 'color',
    'settings'     => 'type_nav_color',
    'label'       => __( 'Nav Color', 'congdongweb-admin' ),
	'section'     => 'main_bar',
    'transport' => $transport
));

Congdongweb_Option::add_field( 'option',  array(
    'type'        => 'color',
    'settings'     => 'type_nav_color_hover',
    'label'       => __( 'Nav Color :hover', 'congdongweb-admin' ),
	'section'     => 'main_bar',
    'transport' => $transport
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'color-alpha',
    'alpha' => true,
    'settings'     => 'header_icons_color',
    'label'       => __( 'Icons Color', 'congdongweb-admin' ),
    'section'     => 'main_bar',
	'default'     => '',
	'transport' => $transport
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'color-alpha',
    'alpha' => true,
    'settings'     => 'header_icons_color_hover',
    'label'       => __( 'Icons Color :hover', 'congdongweb-admin' ),
    'section'     => 'main_bar',
	'default'     => '',
	'transport' => $transport
));



Congdongweb_Option::add_field( '', array(
    'type'        => 'custom',
    'settings' => 'custom_title_transparent',
    'label'       => __( '', 'congdongweb-admin' ),
    'section'     => 'main_bar',
    'default'     => '<div class="options-title-divider">Transparent Header</div>',
) );


Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'slider',
	'settings'     => 'header_height_transparent',
	'label'       => __( 'Height - Transparent Header', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'default'     => 90,
	'transport' => 'postMessage',
	'choices'     => array(
		'min'  => 30,
		'max'  => 500,
		'step' => 1
	),
));


Congdongweb_Option::add_field( 'option',  array(
    'type'        => 'color-alpha',
    'settings'     => 'header_bg_transparent',
    'label'       => __( 'Transparent Header Background Color', 'congdongweb-admin' ),
    'section'     => 'main_bar',
	'default'     => '',
	'transport' => 'postMessage',
));

Congdongweb_Option::add_field( 'option',  array(
	'type'        => 'checkbox',
    'settings'     => 'header_bg_transparent_shade',
	'label'       => __( 'Add Shade', 'congdongweb-admin' ),
	'section'     => 'main_bar',
	'transport' => 'postMessage',
	'default'     => 0,
));
