<?php

//Access the WordPress Pages via an Array
$list_pages            = array();
$list_pages_by_id      = array();
$of_pages_obj          = get_pages('sort_column=post_parent,menu_order');
$list_pages['0']       = 'Select a page:';
$list_pages_by_id['0'] = 'Select a page:';
foreach ($of_pages_obj as $of_page) {
    $list_pages[$of_page->post_name] = $of_page->post_title;
    $list_pages_by_id[$of_page->ID] = $of_page->post_title;
}

function congdongweb_customizer_blocks() {
  $blocks = array( false => '-- None --' );
  $items  = congdongweb_get_post_type_items( 'blocks' );

  if ( ! empty( $items ) ) {
    foreach ( $items as $item ) {
      $blocks[ $item->post_name ] = $item->post_title;
    }
  }

  return $blocks;
}

// Set default transport
$transport = 'postMessage';
if ( ! isset( $wp_customize->selective_refresh ) ) {
  $transport = 'refresh';
}

function congdongweb_customizer_transport() {
  global $wp_customize;
  return ! isset( $wp_customize->selective_refresh )
    ? 'refresh'
    : 'postMessage';
}

$image_url = get_template_directory_uri().'/inc/admin/customizer/img/';

function congdongweb_customizer_images_uri() {
  return get_template_directory_uri() . '/inc/admin/customizer/img';
}


function congdongweb_customizer_nav_elements() {
	return apply_filters( 'congdongweb_header_element', array(
		'cart'         => __( 'Cart', 'congdongweb-admin' ),
		'account'      => __( 'Account', 'congdongweb-admin' ),
		'menu-icon'    => __( '☰ Nav Icon', 'congdongweb-admin' ),
		'nav'          => __( 'Main Menu', 'congdongweb-admin' ),
		'nav-top'      => __( 'Top Bar Menu', 'congdongweb-admin' ),
		'nav-vertical' => __( '☰ Vertical Menu', 'congdongweb-admin' ),
		'search'       => __( 'Search Icon', 'congdongweb-admin' ),
		'search-form'  => __( 'Search Form', 'congdongweb-admin' ),
		'social'       => __( 'Social Icons', 'congdongweb-admin' ),
		'contact'      => __( 'Contact', 'congdongweb-admin' ),
		'button-1'     => __( 'Button 1', 'congdongweb-admin' ),
		'button-2'     => __( 'Button 2', 'congdongweb-admin' ),
		'checkout'     => __( 'Checkout Button', 'congdongweb-admin' ),
		'newsletter'   => __( 'Newsletter', 'congdongweb-admin' ),
		'languages'    => __( 'Languages', 'congdongweb-admin' ),
		'divider'      => __( '|', 'congdongweb-admin' ),
		'divider_2'    => __( '|', 'congdongweb-admin' ),
		'divider_4'    => __( '|', 'congdongweb-admin' ),
		'divider_3'    => __( '|', 'congdongweb-admin' ),
		'divider_5'    => __( '|', 'congdongweb-admin' ),
		'block-1'      => __( 'Block 1', 'congdongweb-admin' ),
		'block-2'      => __( 'Block 2', 'congdongweb-admin' ),
		'html'         => __( 'HTML 1', 'congdongweb-admin' ),
		'html-2'       => __( 'HTML 2', 'congdongweb-admin' ),
		'html-3'       => __( 'HTML 3', 'congdongweb-admin' ),
		'html-4'       => __( 'HTML 4', 'congdongweb-admin' ),
		'html-5'       => __( 'HTML 5', 'congdongweb-admin' ),
	) );
}

// Add Hooked Header Elements
$nav_elements = congdongweb_customizer_nav_elements();

$visibility= array(
  '' => __( 'Show for All', 'congdongweb-admin' ),
  'hide-for-small' => __( 'Hide For Mobile', 'congdongweb-admin' ),
  'hide-for-medium' => __( 'Hide For Tablet', 'congdongweb-admin' ),
  'show-for-small' => __( 'Show For Mobile', 'congdongweb-admin' ),
  'show-for-medium' => __( 'Show For Tablet', 'congdongweb-admin' ),
  'show-for-large' => __( 'Show For Desktop', 'congdongweb-admin' ),
);

$nav_styles_img = array(
  '' => $image_url . 'nav-default.svg',
  'divided' => $image_url . 'nav-divided.svg',
  'line' => $image_url . 'nav-line.svg',
  'line-grow' => $image_url . 'nav-line-grow.svg',
  'line-bottom' => $image_url . 'nav-line-bottom.svg',
  'box' => $image_url . 'nav-box.svg',
  'outline' => $image_url . 'nav-outline.svg',
  'pills' => $image_url . 'nav-pills.svg',
  'tabs' => $image_url . 'nav-tabs.svg'
);

$smart_links = __( '', 'congdongweb-admin' );

$sizes = array(
    'xxlarge' => __( 'XX Large', 'congdongweb-admin' ),
    'xlarge' => __( 'X Large', 'congdongweb-admin' ),
    'larger' => __( 'Larger', 'congdongweb-admin' ),
    'large' => __( 'Large', 'congdongweb-admin' ),
    'medium' => __( 'Medium', 'congdongweb-admin' ),
    'small' => __( 'Small', 'congdongweb-admin' ),
    'smaller' => __( 'Smaller', 'congdongweb-admin' ),
    'xsmall' => __( 'X Small', 'congdongweb-admin' ),
);

$button_styles = array(
	''          => __( 'Default', 'congdongweb-admin' ),
	'outline'   => __( 'Outline', 'congdongweb-admin' ),
	'underline' => __( 'Underline', 'congdongweb-admin' ),
	'shade'     => __( 'Shade', 'congdongweb-admin' ),
	'bevel'     => __( 'Bevel', 'congdongweb-admin' ),
	'gloss'     => __( 'Gloss', 'congdongweb-admin' ),
	'link'      => __( 'Link', 'congdongweb-admin' ),
);

$nav_sizes = array(
  'xsmall' => __( 'XS', 'congdongweb-admin' ),
  'small' => __( 'S', 'congdongweb-admin' ),
  '' => __( 'Default', 'congdongweb-admin' ),
  'medium' => __( 'M', 'congdongweb-admin' ),
  'large' => __( 'L', 'congdongweb-admin' ),
  'xlarge' => __( 'XL', 'congdongweb-admin' ),
);

$nav_spacing = array(
  'xsmall' => __( 'XS', 'congdongweb-admin' ),
  'small' => __( 'S', 'congdongweb-admin' ),
  '' => __( 'Default', 'congdongweb-admin' ),
  'medium' => __( 'M', 'congdongweb-admin' ),
  'large' => __( 'L', 'congdongweb-admin' ),
  'xlarge' => __( 'XL', 'congdongweb-admin' ),
);


$bg_repeat = array(
  "repeat" => "Tiled",
  "repeat-x" => "Repeat X",
  "repeat-y" => "Repeat Y",
  "no-repeat" => "No Repeat"
);
